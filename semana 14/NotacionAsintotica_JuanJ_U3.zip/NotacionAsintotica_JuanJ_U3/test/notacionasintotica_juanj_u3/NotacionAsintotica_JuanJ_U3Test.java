/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package notacionasintotica_juanj_u3;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ESPE
 */
public class NotacionAsintotica_JuanJ_U3Test {
    
    public NotacionAsintotica_JuanJ_U3Test() {
    }

    /**
     * Test of factorial method, of class NotacionAsintotica_JuanJ_U3.
     */
    @Test
    public void testFactorial() {
        System.out.println("factorial");
        int n = 5;
        int expResult = 120;
        int result = NotacionAsintotica_JuanJ_U3.factorial(n);
        assertEquals(expResult, result);
    }

    /**
     * Test of main method, of class NotacionAsintotica_JuanJ_U3.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        NotacionAsintotica_JuanJ_U3.main(args);
    }
    
}
