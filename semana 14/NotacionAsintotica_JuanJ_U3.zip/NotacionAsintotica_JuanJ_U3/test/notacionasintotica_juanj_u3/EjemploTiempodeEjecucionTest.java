
package notacionasintotica_juanj_u3;

import org.junit.Test;
import static org.junit.Assert.*;

public class EjemploTiempodeEjecucionTest {
    
    public EjemploTiempodeEjecucionTest() {
    }

    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = {"a"};
        EjemploTiempodeEjecucion.main(args);

    }

    @Test
    public void testOrdenamientoBurbuja() {
        System.out.println("ordenamientoBurbuja");
        int[] arreglo = null;
        EjemploTiempodeEjecucion.ordenamientoBurbuja(arreglo);

    }
    
}
