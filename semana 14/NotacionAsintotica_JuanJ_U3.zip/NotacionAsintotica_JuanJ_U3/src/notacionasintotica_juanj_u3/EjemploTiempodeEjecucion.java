
package notacionasintotica_juanj_u3;

public class EjemploTiempodeEjecucion {
    public static void main(String[] args){
        // Crear un arreglo de ejemplo (puede ser cualquier tipo de datos y tamaño)
        int[] arreglo = {5, 2, 7, 1, 8, 4, 9, 3, 6,10,15,60,80,90,30,69,100};

        // Obtener el tiempo actual antes de ejecutar el algoritmo
        long tiempoInicial = System.currentTimeMillis();

        // Llamar al método para ejecutar el algoritmo que quieres medir
        // Por ejemplo, aquí podemos ordenar el arreglo utilizando el algoritmo de ordenamiento burbuja
        System.out.println("lista sin ordenar:");
        for(int i=0;i<arreglo.length;i++){
        System.out.print(" "+arreglo[i]);
        }
        System.out.println("");
        ordenamientoBurbuja(arreglo);
        System.out.println("lista ordenada:");
        for(int i=0;i<arreglo.length;i++){
        System.out.print(" "+arreglo[i]);
        }
        System.out.println("");
        // Obtener el tiempo actual después de ejecutar el algoritmo
        long tiempoFinal = System.currentTimeMillis();

        // Calcular el tiempo total de ejecución
        long tiempoTotal = tiempoFinal - tiempoInicial;

        // Imprimir el tiempo total de ejecución en milisegundos
        System.out.println("Tiempo total de ejecución: " + tiempoTotal + " milisegundos");
    }

    // Ejemplo de algoritmo de ordenamiento burbuja
    public static void ordenamientoBurbuja(int[] arreglo) {
        int n = arreglo.length;
        int temp;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arreglo[j] > arreglo[j + 1]) {
                    // intercambiar arreglo[j] y arreglo[j+1]
                    temp = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = temp;
                }
            }
        }
    }
}

