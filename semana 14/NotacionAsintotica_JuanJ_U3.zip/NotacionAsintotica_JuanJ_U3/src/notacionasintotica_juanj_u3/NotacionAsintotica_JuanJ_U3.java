
package notacionasintotica_juanj_u3;

public class NotacionAsintotica_JuanJ_U3 {

    //Metodo para calcular el factorial de un número
    public static int factorial(int n) {
        if (n == 0)
            return 1;
        else
            return n * factorial(n - 1);
    }

    public static void main(String[] args) {
        int n = 5; // Numero el cual se desea buscar la factorial

        //Calcular el factorial
        int resultado = factorial(n);

        //Imprime en pantalla el resultado de la factorial
        System.out.println("El factorial de " + n + " es: " + resultado);
    }
}
    

