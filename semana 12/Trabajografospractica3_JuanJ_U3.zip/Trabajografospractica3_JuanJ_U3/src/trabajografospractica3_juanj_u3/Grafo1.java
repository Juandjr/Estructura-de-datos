
package trabajografospractica3_juanj_u3;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Grafo1 {
    
    private Map<String, List<String>> nodos;
    
    public Grafo1(){
        this.nodos = new HashMap<>();
    }    
    
    public void agregarNodo(String nodo){
        nodos.put(nodo, new LinkedList<>());
    }
    
    public void agregarArista(String origen, String destino){
        nodos.get(origen).add(destino);
    }
    
    public List<String> obtenerVecinos(String nodo){
        return nodos.get(nodo);
    }
    
    public void mostrarGrafo(){
        for(Map.Entry<String ,List<String>>entry: nodos.entrySet()){
        System.out.println(entry.getKey()+" -> ");
        System.out.println(String.join(", ", entry.getValue()));
        }
    }
}
