/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajografospractica3_juanj_u3;

import java.util.List;

/**
 *
 * @author ESPE
 */
public class Trabajografospractica3_JuanJ_U3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Grafo1 grafo = new Grafo1();
        grafo.agregarNodo("A");
        grafo.agregarNodo("K");
        grafo.agregarNodo("M");
        grafo.agregarNodo("N");
        grafo.agregarNodo("O");
        grafo.agregarNodo("P");
        grafo.agregarNodo("Q");
        
        grafo.agregarArista("A", "B");
        grafo.agregarArista("A", "C");
        grafo.agregarArista("B", "D");
        grafo.agregarArista("C", "D");
        
        grafo.mostrarGrafo();
        
        List<String> vecinosDeA = grafo.obtenerVecinos("A");
        System.out.println("Vecinos de A: "+vecinosDeA);
        List<String> vecinosDeB = grafo.obtenerVecinos("B");
        System.out.println("Vecinos de B: "+vecinosDeB);
        List<String> vecinosDeC = grafo.obtenerVecinos("C");
        System.out.println("Vecinos de C: "+vecinosDeC);
        List<String> vecinosDeD = grafo.obtenerVecinos("D");
        System.out.println("Vecinos de D: "+vecinosDeD);
    }
    
}
