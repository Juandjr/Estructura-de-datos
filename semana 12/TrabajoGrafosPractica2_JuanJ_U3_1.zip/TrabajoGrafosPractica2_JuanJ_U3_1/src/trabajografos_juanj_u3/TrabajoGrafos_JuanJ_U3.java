
package trabajografos_juanj_u3;

import java.util.List;

public class TrabajoGrafos_JuanJ_U3 {

    public static void main(String[] args) {
        // TODO code application logic here
        Grafo1 grafo = new Grafo1();
        grafo.agregarNodo("A");
        grafo.agregarNodo("B");
        grafo.agregarNodo("C");
        grafo.agregarNodo("D");
        
        grafo.agregarArista("A", "B");
        grafo.agregarArista("A", "C");
        grafo.agregarArista("B", "D");
        grafo.agregarArista("C", "D");
        
        grafo.mostrarGrafo();
        
        List<String> vecinosDeA = grafo.obtenerVecinos("A");
        System.out.println("Vecinos de A: "+vecinosDeA);
        List<String> vecinosDeB = grafo.obtenerVecinos("B");
        System.out.println("Vecinos de B: "+vecinosDeB);
        List<String> vecinosDeC = grafo.obtenerVecinos("C");
        System.out.println("Vecinos de C: "+vecinosDeC);
        List<String> vecinosDeD = grafo.obtenerVecinos("D");
        System.out.println("Vecinos de D: "+vecinosDeD);
    }
    
}
