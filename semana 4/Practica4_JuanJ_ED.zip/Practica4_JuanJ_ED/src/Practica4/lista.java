package Practica4;
public class lista {
	public Nodo primero;
	
	public lista () {
		primero = null;
	}
	
	public boolean vacia() {
		return (primero==null);
	}
	
	public void insertarLista(Object d) {
		Nodo nuevoNodo = new Nodo(d);
		nuevoNodo.siguiente = primero;
		primero = nuevoNodo;
	}
	
	public void mostrarLista() {
		System.out.println("Lista (primero-> ultimo): ");
		Nodo nodoActual = primero;
		
		while (nodoActual!=null) {
			nodoActual.mostrarNodo();
			nodoActual = nodoActual.siguiente;
		}
		
		System.out.println("");
	}
	
	public Nodo buscarLista(Object dato) {
		Nodo nodoActual = primero;
		
		while(nodoActual.dato.equals(dato)) {
			if(nodoActual.siguiente == null) {
				return null;
			}else {
				nodoActual = nodoActual.siguiente;
			}
		}
		return nodoActual;
	}
	
	public Nodo insertar(Object valorExistente, Object valorNuevo) {
		Nodo nuevoNodo = new Nodo(valorNuevo);
		Nodo nodoActual = primero;
		
		while(!nodoActual.dato.equals(valorExistente)) {
			if(nodoActual.siguiente==null) {
			}else {
				nodoActual = nodoActual.siguiente;
			}
		}
		nuevoNodo.siguiente = nodoActual.siguiente;
		nodoActual.siguiente = nuevoNodo;
		return nuevoNodo;
	}
	
}
