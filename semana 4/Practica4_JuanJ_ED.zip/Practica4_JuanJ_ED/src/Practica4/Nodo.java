package Practica4;
public class Nodo {
    public Object dato; //Representa un dato numérico asociado al nodo.
    public Nodo siguiente;  
    //Este es el constructor de la clase. Toma un parámetro d que se utiliza para inicializar el atributo 
    //dato del objeto Nodo recién creado.
    public Nodo(Object d) {
        dato = d;
    } 
    //metodo que me imprima el valor del campo de dato
    public void mostrarNodo(){
        System.out.println("{"+dato+ "}");
    }
}
