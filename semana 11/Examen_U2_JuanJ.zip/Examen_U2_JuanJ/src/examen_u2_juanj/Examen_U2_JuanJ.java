/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen_u2_juanj;

import java.util.Scanner;

/**
 *
 * @author ESPE
 */
public class Examen_U2_JuanJ {

    /**
     * @param args the command line arguments
     */
    private Nodo arbol1 = null;
    Directorio directorio = new Directorio();
    public static void main(String[] args) {
        Examen_U2_JuanJ xd = new Examen_U2_JuanJ ();
        xd.run();
        
    }
    
    public void run(){
        int opc, valoringre = 0;
        String nombredir = null; 
        String nombrearchiv = null;
        Archivos directorioCreado = new Archivos(nombredir);
        Scanner scan = new Scanner(System.in);
        System.out.println("=========Menu de Árbol de Directorios==========");
        System.out.println("1.agregar un nuevo directorio");
        System.out.println("2.agregar un archivo a un directorio existente");
        System.out.println("3.eliminar un directorio o archivo");
        System.out.println("4.mostrar la estructura del árbol de directorios");
        System.out.println("5.buscar un archivo específico");
        System.out.println("0.Salir");
        System.out.println("===============================================");
        opc = scan.nextInt();
        while (opc!=0){
            switch(opc){
                case 1:
                    System.out.println("Ingrese el nombre del directorio: ");
                    nombredir = scan.next();
                    directorioCreado.nombreArchivo = nombredir;
                    directorio.agregarNuevoDirect(directorioCreado);
                    System.out.println("Nuevo directorio creado correctamente");
                    valoringre++;
                    break;
                case 2:
                    if(valoringre == 0){
                        System.out.println("No existen directorios creados");
                    }else{
                        System.out.println("Ingrese el nombre del archivo: ");
                        nombrearchiv = scan.next();
                        Archivos nombreArchivo = new Archivos(nombrearchiv);
                        directorio.agregarArchivoADirectorio(directorioCreado, nombreArchivo);
                    }
                    break;
                case 3:
                    if(valoringre == 0){
                        System.out.println("No existen directorios o archivos creados");
                    }else{
                    NodoEliminar();
                    }
                    break;
                case 4:
                    if(valoringre == 0){
                        System.out.println("No existen directorios o archivos creados");
                    }else{
                    directorio.imprimirArbol();
                    }
                    break;
                case 5:
                    if(valoringre == 0){
                        System.out.println("No existen directorios o archivos creados");
                    }else{
                    buscarNodo();
                    }
                    break;
                default:
                    System.out.println("Opcion no valida/ Seleccione alguna de las opciones mostradas en el programa");
                    break;
            }
            System.out.println("=========Menu de Árbol de Directorios==========");
            System.out.println("1.agregar un nuevo directorio");
            System.out.println("2.agregar un archivo a un directorio existente");
            System.out.println("3.eliminar un directorio o archivo");
            System.out.println("4.mostrar la estructura del árbol de directorios");
            System.out.println("5.buscar un archivo específico");
            System.out.println("0.Salir");
            System.out.println("===============================================");
            opc = scan.nextInt();
        }
        System.out.println("Gracias por ingresar al programa");

    }
    public void buscarNodo(String nombre, boolean eliminar) {
 int rondas = 0;
 Nodo buscando = arbol1;
 Nodo previo = null;
 while (buscando != null) {
 rondas++;
 if (nombre == buscando.valor) break;
 else previo = buscando;
 if (nombre != buscando.valor) buscando = buscando.izquierda;
 else buscando = buscando.derecha;
 }
 if (buscando == null) System.out.println("\nNodo " + nombre + " no encontrado");
 else {
 if (!eliminar) System.out.println("\nNodo " + nombre + " encontrado después de " +
rondas + " rondas");
 else eliminarNodoArbol(buscando, previo);
 }
 }
    public void buscarNodo() {
 Scanner scanner = new Scanner(System.in);
 System.out.print("¿Que archivo o directorio desea buscar?: ");
 String nombre = scanner.next();
 buscarNodo(nombre, false);
 }
    public void NodoEliminar() {
 Scanner scanner = new Scanner(System.in);
 System.out.print("¿Que archivo o directorio desea buscar?: ");
 String nombre = scanner.next();
 buscarNodo(nombre, true);
 }
    
 private void eliminarNodoArbol(Nodo aux, Nodo prev) {
 if (aux != null) {
 eliminarNodoArbol(aux.izquierda, aux);
 eliminarNodoArbol(aux.derecha, aux);
 System.out.println("\nNodo Eliminado: " + aux.valor);
 if (prev != null) {
 if (aux.valor != prev.valor) prev.izquierda = null;
 else prev.derecha = null;
 }
 if (aux == arbol1) arbol1 = null;
 // Borrar nodo.
 aux = null;
 }
 }
}
