
package examen_u2_juanj;

public class Nodo {
    public String valor;
    public Nodo izquierda;
    public Nodo derecha;
    
    public Nodo(String valor){
        this.valor = valor;
        derecha = null;
        izquierda = null;
    }
}
