
package examen_u2_juanj;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Directorio {
    LinkedList archivos = new LinkedList();
    LinkedList subDirectori = new LinkedList();
    private Map<Archivos, List<Archivos>> relaciones;
    
    Directorio(){
        this.relaciones = new HashMap<>();
    }
   
   public void agregarNuevoDirect(Archivos archivo) {
        relaciones.put(archivo, new ArrayList<>());
        archivos.add(archivo);
   }
   
   public void agregarDirectorioAarchivo(Archivos archivo, Archivos subDirectorio) {
        if (relaciones.containsKey(archivo)) {
            subDirectori.add(relaciones.get(archivo).add(subDirectorio));
        }
   }
   
   public void agregarArchivoADirectorio(Archivos subDirectorio, Archivos archivo) {
        if (relaciones.containsKey(subDirectorio)) {
            relaciones.get(subDirectorio).add(archivo);
        }
   }
   
   public void imprimirArbol() {
        for (Map.Entry<Archivos, List<Archivos>> entry : relaciones.entrySet()) {
            Archivos archivo = entry.getKey();
            List<Archivos> archiv = entry.getValue();
            System.out.println("Nombre directorio: " + archivo.getNombreArchivo());
            System.out.println("Archivos dentro:");
            for (Archivos directorio : archiv) {
                System.out.println(" - " + directorio.getNombreArchivo());
            }
            System.out.println("\n");
        }
    }
}
