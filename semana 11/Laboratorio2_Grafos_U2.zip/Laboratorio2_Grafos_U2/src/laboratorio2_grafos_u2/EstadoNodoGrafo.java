
package laboratorio2_grafos_u2;

public enum EstadoNodoGrafo {
 NoVisitado,
 Visitado,
 VisitadoParcialmente
}
