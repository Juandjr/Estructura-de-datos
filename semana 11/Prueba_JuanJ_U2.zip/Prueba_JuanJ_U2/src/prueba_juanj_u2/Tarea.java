package prueba_juanj_u2;
//clase producto que es la clase que tiene como propocito la funcion de agregar productos al restaurante
import java.util.Stack;

public class Tarea {
    //declaracion de metodos que se utilizaran en la clase producto
    int id;
    String desc;
    boolean completada;
    Stack<Tarea> tareasLista = new Stack<Tarea>();
    //constructor de la clase producto
    public Tarea(int id, String desc, boolean completada){
        this.id = id;
        this.desc = desc;
        this.completada = completada;
    }
    
    //constructor de tipo string que nos devuelve el producto que se ingrese
    public String getTarea(){
        String Tar = String.format("""
                                    ID:            %s
                                    Descripcion:   %s
                                    Completada:    %s
                                    """, id, desc, completada);
        return Tar;
    }
}