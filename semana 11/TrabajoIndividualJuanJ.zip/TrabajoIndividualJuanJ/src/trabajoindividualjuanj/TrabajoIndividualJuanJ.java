
package trabajoindividualjuanj;

public class TrabajoIndividualJuanJ {

    public static void main(String[] args) {
        // TODO code application logic here
        VentanaInicio ventanainicio = new VentanaInicio();
        ventanainicio.setVisible(true);
    }
    
}
