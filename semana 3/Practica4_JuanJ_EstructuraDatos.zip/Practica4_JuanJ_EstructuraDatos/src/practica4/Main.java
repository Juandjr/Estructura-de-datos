package practica4;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> colores=new ArrayList<String>();
		colores.add("Amarillo");
		colores.add("rojo");
		System.out.println("colores: "+colores);
	}

}
