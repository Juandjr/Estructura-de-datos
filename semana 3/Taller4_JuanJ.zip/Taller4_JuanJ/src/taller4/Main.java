package taller4;
public class Main {
	static void sumarMatrices(int[][] matriz1, int[][] matriz2, int[][] matriz3) {
        // Primero hacer la Duncion que nos realize la suma de las matrizes
        int[][] matrizSuma = new int[matriz1.length][matriz1[0].length];//aqui se verfica la longitud de la matriz con el .length
        for (int y = 0; y < matriz1.length; y++) {
            for (int x = 0; x < matriz1[y].length; x++) {
                int numeroMatriz1 = matriz1[y][x];
                int numeroMatriz2 = matriz2[y][x];
                int numeroMatriz3 = matriz3[y][x];
                int suma = numeroMatriz1 + numeroMatriz2 + numeroMatriz3;
                matrizSuma[y][x] = suma;
            }
        }
        // Después imprimir los encabezados para la diferenzacion de las matrizes y las sumas
        System.out.println("Matriz 1\t\tMatriz 2\tMatriz 3\tResultado de la Suma");
        for (int x = 0; x < 62; x++) {
            System.out.print("_");
        }
        System.out.println();
        
        //Imprimir los datos de la matriz 1
        for (int y = 0; y < matriz1.length; y++) {
            for (int x = 0; x < matriz1[y].length; x++) {
            	//el %4d este sirve para el espaciado entre entre letras
                System.out.printf("%4d ", matriz1[y][x]);
            }
            //estas lineas sirve para separar las matrizes para evitar confusiones
            System.out.print(" | ");
            //Imprimir los datos de la matriz 2
            for (int x = 0; x < matriz2[y].length; x++) {
                System.out.printf("%4d ", matriz2[y][x]);
            }
            System.out.print(" | ");
          //Imprimir los datos de la matriz 3
            for (int x = 0; x < matriz3[y].length; x++) {
                System.out.printf("%4d ", matriz3[y][x]);
            }
            System.out.print(" | ");
            //Imprimir los datos del resultado de la suma de los matrizes
            for (int x = 0; x < matrizSuma[y].length; x++) {
                System.out.printf("%4d ", matrizSuma[y][x]);
            }
            System.out.print(" | ");
            System.out.println();
        }
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//este es la matriz 1 el cual tiene los valores presentes aunque se le puede modificar al gusto su tamaño como los valores dentro
		int[][] matriz1 = {
                {2, 0, 2},
                {0, 69, 0},
                {2, 0, 2},
        };
		//este es la matriz 2 el cual tiene los valores presentes aunque se le puede modificar al gusto su tamaño como los valores dentro
        int[][] matriz2 = {
                {0, 1, 0},
                {1, 0, 1},
                {0, 1, 0},
        };
        int[][] matriz3 = {
                {0, 1, 0},
                {1, 0, 1},
                {0, 1, 0},
        };
        //este es el que llama a la funcion de sumar matrices dentro de main para que realize la suma 
        sumarMatrices(matriz1, matriz2, matriz3);
		
	}

}
