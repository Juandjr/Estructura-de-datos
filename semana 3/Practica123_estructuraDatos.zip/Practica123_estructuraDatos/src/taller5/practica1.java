package taller5;
import java.util.Scanner;
public class practica1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//declarasion de las variables y atributos que se va a realizar 
		Scanner scan = new Scanner(System.in);
		int a,b,c,d,e,f,g,h,i,j,k;
		int tamArreglo1;
		//mostrar en la pantalla para que el usuario ingrese el tamaño del arreglo
		System.out.println("Ingrese el tamaño del arreglo que desea: ");
		tamArreglo1 = scan.nextInt();
		//creacion del arreglo "numeros" que se va a utilizar con el tamaño que el usuario desee
		int[] numeros = new int[tamArreglo1];
		//elaboracion de un bucle que ingrese los datos al arreglo
		for(i=0;i<=(tamArreglo1-1);i++) {
			System.out.println("Ingrese el valor "+(i)+" del array: ");
			numeros[i]= (a = scan.nextInt());
		}		
		//Bucle el cual nos va a mostrar los datos ingresados al arreglo numeros
		System.out.println("Los valores ingresados son: ");
		for(j = 0; j <=(tamArreglo1-1) ; j++) {
			System.out.println("Valor ingresado N"+(j+1)+" es: "+ numeros[j]);
		}
	}

}
