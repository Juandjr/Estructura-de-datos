package taller5;
import java.util.Scanner;

public class practica2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int a,b,c,d,e;
		System.out.println("Ingrese el valor 1 del array: ");
		a = scan.nextInt();
		System.out.println("Ingrese el valor 2 del array: ");
		b = scan.nextInt();
		System.out.println("Ingrese el valor 3 del array: ");
		c = scan.nextInt();
		System.out.println("Ingrese el valor 4 del array: ");
		d = scan.nextInt();
		System.out.println("Ingrese el valor 5 del array: ");
		e = scan.nextInt();
		int numeros[] = {a,b,c,d,e};
		System.out.println("Los valores ingresados son: ");
		for(int i = 4; i<=4 && i>-1 ; i--) {
			System.out.println("Valor ingresado N"+(i+1)+" es: "+ numeros[i]);
		}
	}

}
