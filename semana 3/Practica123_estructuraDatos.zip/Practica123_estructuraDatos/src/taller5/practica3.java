package taller5;

import java.util.Scanner;

public class practica3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int a,i,j,k,l,m;
		double acumposi = 0;
		double acumnega = 0;
		double posi = 0;
		double nega = 0;
		double mediaposi = 0;
		double medianega = 0;
		int ceros=0;
		int tamArreglo1;
		System.out.println("Ingrese el tamaño del arreglo que desea: ");
		tamArreglo1 = scan.nextInt();
		int[] numeros = new int[tamArreglo1];
		for(i=0;i<=(tamArreglo1-1);i++) {
			System.out.println("Ingrese el valor "+(i+1)+" del array: ");
			numeros[i]= (a = scan.nextInt());
		}		
		System.out.println("Los valores ingresados son: ");
		for(j = 0; j <=(tamArreglo1-1) ; j++) {
			System.out.println("Valor ingresado N"+(j+1)+" es: "+ numeros[j]);
		}
		
		System.out.print("La media de los numero positivos es: ");
		for(k = 0; k <=(tamArreglo1-1) ; k++) {
			if (numeros[k]>0) {
				mediaposi++;
				acumposi += numeros[k];
				posi = acumposi/mediaposi;
			}
		}
		System.out.println(posi);
		
		System.out.print("La media de los numero negativos es: ");
		for(l = 0; l <=(tamArreglo1-1) ; l++) {
			if (numeros[l]<0) {
				medianega++;
				acumnega += numeros[l];
				nega = acumnega/medianega;
			}
		}
		System.out.println(nega);
		
		System.out.print("El conteo de 0 que se realizo es de: ");
		for(m = 0; m <=(tamArreglo1-1) ; m++) {
			if (numeros[m]==0) {
				ceros++;
			}
		}
		System.out.println(ceros);
	}

}
