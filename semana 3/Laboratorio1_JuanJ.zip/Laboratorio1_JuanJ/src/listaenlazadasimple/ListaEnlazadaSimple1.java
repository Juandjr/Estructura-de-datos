package listaenlazadasimple;

public class ListaEnlazadaSimple1 {
	//creando las variables que se van a utilizar
	private Nodo primero;
	
	//elaboramos un constructor
	public ListaEnlazadaSimple1() {
		primero = null;
	}
	
	//Metodo que va a verificar si la lista esta vacia
	public boolean vacia() {
		return (primero==null);
	}
	
	//metodo que inseta datos en la cabeza de la lista
	public void insertarCabezaLista(Object d) {
		Nodo nuevoNodo = new Nodo(d);
		nuevoNodo.siguiente = primero;
		
		primero = nuevoNodo;
	}
	
	//Elimina el nodo que se ecuentre en la sima de la lista (pero que esta no este vacia)
	public Nodo eliminarCabezaLista() {
		Nodo temp = primero;
		primero = primero.siguiente;
		
		return temp;
	}
	
	//imprime en la pantalla el contenido de los nodos de la lista
	public void mostrarLista() {
		System.out.println("Lista (primero-> ultimo): ");
		Nodo nodoActual = primero;
		
		while (nodoActual!=null) {
			nodoActual.mostrarNodo();
			nodoActual = nodoActual.siguiente;
		}
		
		System.out.println("");
	}
	
	//metodo que para buscar un dato de una lista 
	public Nodo buscarLista(Object dato) {
		Nodo nodoActual = primero;
		
		while(nodoActual.dato.equals(dato)) {
			if(nodoActual.siguiente == null) {
				return null;
			}else {
				nodoActual = nodoActual.siguiente;
			}
		}
		return nodoActual;
	}
	
	//metodo que nos ayuda con eliminar un objeto ingresado como parametro
	public Nodo eliminar(Object dato) {
		Nodo nodoActual = primero;
		Nodo nodoAnterior = primero;
		
		while(!nodoActual.dato.equals(dato)){
			if(nodoActual.siguiente==null) {
		}else {
			nodoAnterior = nodoActual;
			nodoActual = nodoActual.siguiente;
		}
	}
		if(nodoActual == primero) {
			primero = primero.siguiente;
		}else {
			nodoAnterior.siguiente=nodoActual.siguiente;
		}
		
	return nodoActual;
	}
	
	//Metodo que nos ayuda a insertar valores dentro de la lista
	public Nodo insertar(Object valorExistente, Object valorNuevo) {
		Nodo nuevoNodo = new Nodo(valorNuevo);
		Nodo nodoActual = primero;
		
		while(!nodoActual.dato.equals(valorExistente)) {
			if(nodoActual.siguiente==null) {
			}else {
				nodoActual = nodoActual.siguiente;
			}
		}
		
		nuevoNodo.siguiente = nodoActual.siguiente;
		nodoActual.siguiente = nuevoNodo;
		
		return nuevoNodo;
	}
	
}

