package listaenlazadasimple;

public class Nodo {
	//ingresando las variables que se van a utilizar
	public Object dato;
	public Nodo siguiente;
	//elaboramos una construccion 
	public Nodo(Object d) {
		dato = d;
		siguiente = null;
	}
	//metodo para mostrar los datos dentro del dato
	public void mostrarNodo() {
		System.out.println("("+ dato + ")");
	}
}
