package listaenlazadasimple;
import java.util.Scanner;
public class ListaEnlazadaSimpleApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//elaboramos la instacia que llama a la clase ListaEnlazadaSimple1
		ListaEnlazadaSimple1 lista = new ListaEnlazadaSimple1();
		int tamArreglo1;
		String a,b,c,f,e;
		Scanner scan = new Scanner(System.in);
		
		//Creacion de codigo para ingresar los datos que deseemos
		System.out.println("Ingrese el tamaño de la lista que desea: ");
		tamArreglo1 = scan.nextInt();
		for(int i=0;i<=(tamArreglo1-1);i++) {
			System.out.println("Ingrese el valor "+(i+1)+" de la lista: ");
			f = scan.next();
			lista.insertarCabezaLista(f);
		}
		
		//Mostrar daos de los nodos de la lista
		lista.mostrarLista();
		
		//Insertamos un nuevo nodo entre dos nodos de la lista
		System.out.println("Ingrese un valor nuevo para la lista: ");
		a = scan.next();
		System.out.println("Ingrese el un valorExistente donde quiera que el nodo se añada alado: ");
		b = scan.next();
		Nodo nodo = lista.insertar(b, a);
		if(nodo == null) {
			System.out.println("No se pudo insertar nuevo nodo");
		}else {
			System.out.println("Nodo se inserto Correctamente");
		}
		
		//Volvemos a mostrar nodos de la lista enlazada 
		lista.mostrarLista();
		
		//buscamos nodo en la lista enlazada simple
		System.out.println("Ingrese el un valorExistente que quiera buscar: ");
		c = scan.next();
		nodo = lista.buscarLista(c);
		if(nodo != null) {
			System.out.println("Se encontro nodo con el dato buscado");
		}else {
			System.out.println("No se encontro nodo con el dato buscado");
		}
		
		//borramos nodos de la lista enlazada simple
		while(!lista.vacia()) {
			nodo = lista.eliminarCabezaLista();
			System.out.println("Nodo eliminado");
			nodo.mostrarNodo();
					System.out.println("");
		}
		
		//comprobamos si la lista esta vacia
		System.out.println("Lista enlazada simple esta vacia? "+ lista.vacia());
		lista.mostrarLista();
		
		//insertamos nuevos nodos a la lista enlazada simple
		System.out.println("Ingrese el tamaño de la lista que desea: ");
		tamArreglo1 = scan.nextInt();
		System.out.println("Ingresamos nuevos datos: ");
		for(int i=0;i<=(tamArreglo1-1);i++) {
			System.out.println("Ingrese el valor "+(i+1)+" de la lista: ");
			f = scan.next();
			lista.insertarCabezaLista(f);
		}
		
		//Mostramos los nodos de la lista
		lista.mostrarLista();
		
		//eliminamos un nodo
		System.out.println("Ingrese un nodoExistente para borrar: ");
		e = scan.next();
		lista.eliminar(e);
		
		//Mostramos nuevamente los nodos de la lista
		lista.mostrarLista();
	}

}

