
package busquedagrafo_juaj_u3;

import java.util.Scanner;

public class BusquedaGrafo_JuaJ_U3 {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de vertices que hay: ");
        int cant = scan.nextInt();
        int cantAri;
        int origen;
        int fin;
        int peso;
        Grafo grafo = new Grafo(cant);
        int opc;
        System.out.println("=======Menu de Opciones======");
        System.out.println("1.Ingresar Aristas");
        System.out.println("2.Realizar busqueda");
        System.out.println("3.Mostrar Matriz de adyacencia");
        System.out.println("4.Busqueda en profundidad");
        System.out.println("5.Mostrar las aristas");
        System.out.println("0.Salir");
        opc = scan.nextInt();
        while (opc!=0){
            switch(opc){
                case 1:
                    if(cant==0){
                        System.out.println("No hay valores en el grafo");
                    }else{
                        System.out.println("Ingrese la cantidad de aristas que desea: ");
                        cantAri = scan.nextInt();
                        for(int i=0;i<cantAri;i++){
                            System.out.println("Ingrese el origen de la arista "+(i+1)+" : ");
                            origen = scan.nextInt();
                            System.out.println("Ingrese el final de la arista "+(i+1)+" : ");
                            fin = scan.nextInt();
                            System.out.println("Ingrese el peso de la arista "+(i+1)+" : ");
                            peso = scan.nextInt();
                            grafo.agregarArista(origen, fin, peso);
                        }
                    }
                    break;
                case 2:
                    if(cant==0){
                        System.out.println("No hay valores en el grafo");
                    }else{
                        System.out.println("Ingrese el vertice inicial de la busqueda: ");
                        origen = scan.nextInt();
                        System.out.println("Ingrese el vertice final de la busqueda: ");
                        fin = scan.nextInt();
                        System.out.println("Origen papel del 0 al 4: "+grafo.dijkstra(origen, fin));
                        System.out.println("Peso total de recorrido: "+grafo.sumaPesosAristas(grafo.dijkstra(origen, fin)));
                    }
                    break;
                case 3:
                    if(cant==0){
                        System.out.println("No hay valores en el grafo");
                    }else{
                        grafo.mostrarMatrizAdyacencia();
                    }
                    break;
                case 4:
                    System.out.println("Ingrese el vector que desea buscar: ");
                    int a = scan.nextInt();
                    grafo.DFS(a);
                    break;
                case 5:
                    System.out.println("Se mostran las conexiones de las aristas: ");
                    grafo.mostrarAristasIngresadas();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        System.out.println("=======Menu de Opciones======");
        System.out.println("1.Ingresar Aristas");
        System.out.println("2.Realizar busqueda");
        System.out.println("3.Mostrar Matriz de adyacencia");
        System.out.println("4.Busqueda en profundidad");
        System.out.println("5.Mostrar las aristas");
        System.out.println("0.Salir");
        opc = scan.nextInt();
        }
        System.out.println("Gracias por ingresar");
    }
}
