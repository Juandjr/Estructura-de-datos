package practica6;

import java.util.ArrayList;
import java.util.List;

public class Pilas {
	int tamaño;//tamaño de la pila
	Nodo tope;
	Nodo tope1;
	Nodo tope2;//Nodo en la cima de la pila
	List<String>BolsaTitulo = new ArrayList<>();
	List<String>BolsaAutor = new ArrayList<>();
	List<Integer>BolsaAño = new ArrayList<>();
	public Pilas() {
		this.tamaño=0;
		this.tope=null;
	}
	//metodo para insertar un elemento en la pila(push)
	public void pushTitulo(String valor) {
		Nodo titulo = new Nodo(valor);//Crear un nuevo nodo con el dato
		titulo.siguiente=tope;//El siguiente del nuevo nodo es la cima actual
		tope = titulo; //El nuevo nodo se convierte en la cima
		tamaño++;
	}
	
	public void pushAutor(String valor) {
		Nodo autor = new Nodo(valor);
		autor.siguiente=tope1;//El siguiente del nuevo nodo es la cima actual
		tope1 = autor; //El nuevo nodo se convierte en la cima
	}
	
	public void pushAño(String valor) {
		Nodo año = new Nodo(valor);
		año.siguiente=tope2;//El siguiente del nuevo nodo es la cima actual
		tope2 = año; //El nuevo nodo se convierte en la cima
	}
	
	public void mostrarRega() {
	    if (tope2 == null) {
	        System.out.println("La pila está vacía.");
	        return;
	    }
	    Nodo current = tope2;
	    while (tope2 != null) {
	        if (tope2.año < 2020) {
	            BolsaTitulo.add(tope.valor);
	            BolsaAutor.add(tope1.valor);
	            BolsaAño.add(tope2.año);
	        }
	        current = current.siguiente;
	    }
	    if (BolsaTitulo.size() == 0) {
	        System.out.println("No se encontraron libros menores a 2020.");
	        return;
	    }
	    for (int i = 0; i < BolsaTitulo.size(); i++) {
	        System.out.println("Título: " + BolsaTitulo.get(i));
	        System.out.println("Autor: " + BolsaAutor.get(i));
	        System.out.println("Año: " + BolsaAño.get(i));
	    }
	}
	
	public void mostrarLibrosSobrantes() {
		
		
	}
	
	public String pop(String valor) {//metodo para eliminar y devolver el elemento de la cima de la pila(pop)
		if(tamaño>0) {
			String returnValue = tope.valor;//Obtener el dato en la cima
			tope = tope.siguiente; //Mover la cima al siguiente nodo
			tamaño--;
			return returnValue;
		}else {
			return "-1";//Valor predeterminado para indicar un error
		}
	}
	
	
	
	
}
