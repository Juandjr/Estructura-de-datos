package practica6;
import java.util.Scanner;
public class GenerarPila {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pilas miPila = new Pilas();//Crear una instancia de la pila
		//Operaciones basicas de la pila
		Scanner scan = new Scanner(System.in);
		int opc,cant,dato;
		String A,B,C;
		System.out.println("===Menu de Opciones===");
		System.out.println("1.Ingresar Libros");
		System.out.println("2.Regalar libros menor 2020");
		System.out.println("3.Ordenar Alfabeticamente");
		System.out.println("4.Salir");
		opc = scan.nextInt();
		while(opc !=4) {
			switch(opc) {
			case 1:
				System.out.println("Ingresa la cantidad de libros que desees ingresar");
				cant = scan.nextInt();
				for (int i=0;i<cant;i++) {
					System.out.println("Ingrese el Titulo del libro N° "+(i+1)+" :");
					A = scan.next();
					miPila.pushTitulo(A);
					System.out.println("Ingrese el Autor del libro N° "+(i+1)+" :");
					A = scan.next();
					miPila.pushAutor(A);
					System.out.println("Ingrese el Año de edicion del libro N° "+(i+1)+" :");
					A = scan.next();
					miPila.pushAño(A);
				}
				System.out.println("Los datos han sido ingresados correctamente");
				break;
			case 2:
				miPila.mostrarRega();
				break;
			case 3:
				System.out.println("Verificando si la lista esta vacia: ");
				if(miPila.tamaño!=0) {
					System.out.println("Lista tiene datos dentro");
				}else {
					System.out.println("La pila esta vacia");
				}
				break;
			case 4:
				System.out.println("El tamaño de la pila es de: "+miPila.tamaño);
				break;
			default:
				System.out.println("Opcion no valida");
				break;
			}
			System.out.println("===Menu de Opciones===");
			System.out.println("1.Ingresar Libros");
			System.out.println("2.Regalar libros menor 2020");
			System.out.println("3.Ordenar Alfabeticamente");
			System.out.println("4.Salir");
			opc = scan.nextInt();
		}
		System.out.println("Gracias por ingresar");
	}
}
