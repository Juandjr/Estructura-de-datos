package practica6;

public class Nodo {
	String valor;//Datos almacenados en el nodo
	int año;
	Nodo siguiente;//Referecia al siguiente nodo en la pila 
	
	//Constructor de la clase Nodo
	public Nodo(String valor) {
		this.valor = valor;
		this.siguiente = null;//apunta afuera al vacio
	}
	
}
