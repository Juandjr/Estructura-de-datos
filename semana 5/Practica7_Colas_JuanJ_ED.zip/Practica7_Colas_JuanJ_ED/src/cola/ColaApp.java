package cola;
import java.util.*;
public class ColaApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opc,a;
		Scanner scan = new Scanner(System.in);
		Cola cola = new Cola(5);
		int tamano=0;
		String animales;
		
		System.out.println("===Menu de opciones===");
		System.out.println("1.Agregar datos a la cola");
		System.out.println("2.Mostrar datos de la cola");
		System.out.println("3.Elemento que esta encima de la cola");
		System.out.println("4.Verificar si la cola esta vacia");
		System.out.println("5.Verificar si la cola esta llena");
		System.out.println("6.Mostrar tamaño de la cola");
		System.out.println("7.Vaciar cola");
		System.out.println("8.Salir");
		opc = scan.nextInt();
		while(opc!=8) {
			switch(opc) {
			        case 1:
			         	System.out.println("Ingresa la cantidad de datos que desees ingresar");
				        tamano = scan.nextInt();
		         		for (int i=0;i<tamano;i++) {
			         		System.out.println("Ingrese el dato de la pila N° "+(i+1)+" :");
			         		a = scan.nextInt();
			        		cola.insertar(a);
		         		}
					break;
					case 2:
						for (int j = 0;j<tamano;j++) {
							Object n = cola.frenteCola();
							System.out.print(n);
							System.out.println(" ");
						}
						break;
					case 3:
						System.out.println("");
						System.out.print("Elemento en la cabeza de la cola: ");
						System.out.print(cola.frenteCola());
						System.out.println("");
						break;
					case 4:
						System.out.print("Esta cola esta vacia?");
						System.out.println(cola.colaVacia());
						break;
					case 5:
						System.out.print("Esta cola esta llena?");
						System.out.println(cola.colaLlena());
						break;
					case 6:
						System.out.print("Tamaño de la cola: ");
						System.out.println(cola.tamanoCola());
						break;
					case 7:
						while(!cola.colaVacia()) {
							Object m = cola.quitar();
							System.out.print(m);
							System.out.println(" ");
							
						}
						System.out.println("Han sido eliminados");
						break;
						default:
							System.out.println("Opcion no valida");
							break;
						
			}
			System.out.println("===Menu de opciones===");
			System.out.println("1.Agregar datos a la cola");
			System.out.println("2.Mostrar datos de la cola");
			System.out.println("3.Elemento que esta encima de la cola");
			System.out.println("4.Verificar si la cola esta vacia");
			System.out.println("5.Verificar si la cola esta llena");
			System.out.println("6.Mostrar tamaño de la cola");
			System.out.println("7.Vaciar cola");
			System.out.println("8.Salir");
			opc = scan.nextInt();
		}
		System.out.println("Gracias por ingresar");
	}
}
