module Practica7_Colas_JuanJ_ED {
}