
package arbolbinarioprueba_juanj;

public class Node {//declaracion de la clase Node
    //declaracion de las variables
    public int value;
    public Node left;
    public Node right;
    //constructor de la clase Node
    public Node (int value){//formato del contructor
        this.value = value;
        this.left = null;
        this.right = null;
    }
}
