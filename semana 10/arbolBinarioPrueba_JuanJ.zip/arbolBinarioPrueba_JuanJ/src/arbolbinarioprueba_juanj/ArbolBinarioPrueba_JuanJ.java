
package arbolbinarioprueba_juanj;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ArbolBinarioPrueba_JuanJ {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        int opc;
        String a = "Es verdadero";
        System.out.println("====MENU ARBOL BINARIO====");
        System.out.println("1.Recorrido arbol binario");
        System.out.println("2.invertir arbol binario");
        System.out.println("3.Lista del ultimo nivel");
        System.out.println("4.Profundidad maxima/Nivel");
        System.out.println("5.Validar BTS");
        System.out.println("6.SubArbol");
        System.out.println("7.Primer Ancestro comun");
        System.out.println("0.Salir");
        opc = scan.nextInt();
        while(opc!=0){
            switch(opc){
                case 1:
                    //Actividad 0
                    System.out.println("ACTIVIDAD 0:");
                    Node root = new Node(1);
                    root.left = new Node(2);
                    root.right = new Node(3);
                    root.left.left = new Node(4);
                    root.left.right = new Node(5);
                    root.right.right = new Node(6);
                    root.left.left.left = new Node(7);
                    root.left.right.left = new Node(8);
        
                    System.out.print("IN-ORDER TRAVERSAL: ");
                    BinaryTreeTraversals.inOrdenTraversal(root);
                    System.out.println();

                    System.out.print("PRE-ORDER TRAVERSAL: ");
                    BinaryTreeTraversals.preOrdenTraversal(root);
                    System.out.println();

                    System.out.print("POST-ORDER TRAVERSAL: ");
                    BinaryTreeTraversals.postOrdenTraversal(root);
                    System.out.println();
                break;
                case 2:
                    //Actividad 1
                    System.out.println("ACTIVIDAD 1:");
                    InvertirArbolBinario invertirArbolBinario = new InvertirArbolBinario();
                    Node root1 = new Node(4);
                    root1.left = new Node(2);
                    root1.right = new Node(7);
                    root1.left.left = new Node(1);
                    root1.left.right = new Node(3);
                    root1.right.left = new Node(6);
                    root1.right.right = new Node(9);
                    Node newRoot = invertirArbolBinario. invertirAbol(root1);
                    assertEquals(4, newRoot.value);
                    assertEquals(7, newRoot.left.value);
                    assertEquals(2, newRoot.right.value);
                    assertEquals(9, newRoot.left.left.value);
                    assertEquals(6, newRoot.left.right.value);
                    assertEquals(3, newRoot.right.left.value);
                    assertEquals(1, newRoot.right.right.value);
                    System.out.print("PRE-ORDER TRAVERSAL: ");
                    BinaryTreeTraversals.preOrdenTraversal(newRoot);
                    System.out.println();
                break;
                case 3:
                    //Actividad 2
                    System.out.println("ACTIVIDAD 2:");
                    ListOfDepths listOfDepths = new ListOfDepths();
                    Node root2 = new Node(4);
                    root2.left = new Node(2);
                    root2.right = new Node(7);
                    root2.left.left = new Node(1);
                    root2.left.right = new Node(3);
                    root2.right.left = new Node(6);
                    root2.right.right = new Node(9);
                    List<LinkedList<Node>> result = listOfDepths.listOfDepths(root2);
                    assertEquals(4, result.get(0).get(0).value);
                    assertEquals(2, result.get(1).get(0).value);
                    assertEquals(7, result.get(1).get(1).value);
                    assertEquals(1, result.get(2).get(0).value);
                    assertEquals(3, result.get(2).get(1).value);
                    assertEquals(6, result.get(2).get(2).value);
                    assertEquals(9, result.get(2).get(3).value);
                    System.out.print("PRE-ORDER TRAVERSAL: ");
                    BinaryTreeTraversals.preOrdenTraversal(root2);
                    System.out.println("\nResultado: ");
                    for(int i=0;i<result.size();i++){
                        System.out.print(result.get(i)+" ");
                    }
                    System.out.println();
                break;
                case 4:
                    //Actividad 3
                    System.out.println("ACTIVIDAD 3:");
                    MaximumDepth maxDepth = new MaximumDepth();
                    Node root3 = new Node(4);
                    root3.left = new Node(2);
                    root3.right = new Node(7);
                    root3.left.left = new Node(1);
                    root3.left.right = new Node(3);
                    assertEquals(3, maxDepth.maxDepth(root3));
                    root3.left.left.left = new Node(8);
                    assertEquals(4, maxDepth.maxDepth(root3));
                break;
                case 5:
                    //Actividad 4
                    System.out.println("ACTIVIDAD 4:");
                    ValidateBST validateBst = new ValidateBST();
                    Node root4 = new Node(4);
                    root4.left = new Node(5);
                    root4.right = new Node(7);
                    root4.left.left = new Node(1);
                    root4.left.right = new Node(3);
                    root4.left.left.left = new Node(8);
                    assertFalse(validateBst.isValidBST(root4));
                    root4.left.value = 2;
                    root4.left.left.left = null;
                    assertTrue(validateBst.isValidBST(root4));
                break;
                case 6:
                    //Actividad 5
                    System.out.println("ACTIVIDAD 5:");
                    IsSubTree isSubTree = new IsSubTree();
                    Node first = new Node(4);
                    first.left = new Node(5);
                    first.right = new Node(7);
                    first.left.left = new Node(1);
                    first.left.right = new Node(3);
                    first.left.left.left = new Node(8);
                    Node second = new Node(5);
                    second.left = new Node(1);
                    second.right = new Node(3);
                    second.left.left = new Node(8);
                    assertTrue(isSubTree.isSubtree(first, second));
                    second.right.right = new Node(12);
                    assertFalse(isSubTree.isSubtree(first, second));
                break;
                case 7:
                    //Actividad 6
                    System.out.println("ACTIVIDAD 6:");
                break;
                default:
                    System.out.println("Opcion no valida");
                break;
            }
        System.out.println("====MENU ARBOL BINARIO====");
        System.out.println("1.Recorrido arbol binario");
        System.out.println("2.invertir arbol binario");
        System.out.println("3.Lista del ultimo nivel");
        System.out.println("4.Profundidad maxima/Nivel");
        System.out.println("5.Validar BTS");
        System.out.println("6.SubArbol");
        System.out.println("7.Primer Ancestro comun");
        System.out.println("0.Salir");
        opc = scan.nextInt();
        }
        System.out.println("Gracias por ingresar");
    }

}
