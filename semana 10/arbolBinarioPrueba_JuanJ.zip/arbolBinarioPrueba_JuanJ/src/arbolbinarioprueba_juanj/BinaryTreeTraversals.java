
package arbolbinarioprueba_juanj;

public class BinaryTreeTraversals {//clase para el ordenamiento del arbol
    public static void inOrdenTraversal(Node node){//metodo para el recorrido del arbol de la forma In-Orden
        if(node !=null){
            inOrdenTraversal(node.left);
            System.out.print(node.value+" ");
            inOrdenTraversal(node.right);
    }}
    
    public static void preOrdenTraversal(Node node){
        if(node !=null){
           System.out.print(node.value+" ");
           preOrdenTraversal(node.left);
           preOrdenTraversal(node.right);
    }}
    
    public static void postOrdenTraversal (Node node){
        if(node !=null){
            postOrdenTraversal(node.left);
            postOrdenTraversal(node.right);
            System.out.print(node.value+" ");
    }}
}
