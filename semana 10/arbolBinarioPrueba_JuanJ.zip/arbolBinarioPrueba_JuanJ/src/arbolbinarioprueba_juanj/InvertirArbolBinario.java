
package arbolbinarioprueba_juanj;

public class InvertirArbolBinario{
    public Node invertirAbol(Node root) {
        if (root == null) return null;
        Node tmp = root.left;
        root.left = invertirAbol(root.right);
        root.right = invertirAbol(tmp);
        return root;
    }
}

