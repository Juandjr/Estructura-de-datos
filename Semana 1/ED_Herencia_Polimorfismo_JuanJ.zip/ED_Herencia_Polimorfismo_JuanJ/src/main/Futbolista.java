package main;
//Clase hijas de la clase Seleccion
public class Futbolista extends Seleccion {
	double Pago = 1500;
	int Goles;
	String TipoJugador;
	//Getter de Pago
	public double getPago() {
		return Pago;
	}
	//Setter de Pago
	public void setPago(double pago) {
		this.Pago = pago;
	}
	//Getter de Goles
	public int getGoles() {
		return Goles;
	}
	//Setter de Pago
	public void setGoles(int goles) {
		Goles = goles;
	}
	//Getter de Tipo Jugador
	public String getTipoJugador() {
		return TipoJugador;
	}
	//Setter de Tipo Jugador
	public void setTipoJugador(String tipoJugador) {
		TipoJugador = tipoJugador;
	}
	//Constructor de los atributos que hereda de la clase padre (Seleccion)
	//Getter de Victorias
	public int getVictorias() {
		return Victorias;
	}
	//Setter de victorias
	public void setVictorias(int victorias) {
		Victorias = victorias;
	}
	//Getter de Derrotas 
	public int getDerrotas() {
		return Derrotas;
	}
	//Setter de Derrotas
	public void setDerrotas(int derrotas) {
		Derrotas = derrotas;
	}
	//Getter de Rol
	public String getRol() {
		return Rol;
	}
	//Setter de Rol
	public void setRol(String rol) {
		Rol = rol;
	}
	
}
