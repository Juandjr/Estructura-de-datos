package main;
//Clase hijas de la clase Seleccion
public class Masajista extends Seleccion {
	double Pago = 800;

	//Getter de Pago
	public double getPago() {
		return Pago;
	}
	//Setter de Pago
	public void setPago(double pago) {
		this.Pago = pago;
	}
	//Constructor de los atributos que hereda de la clase padre (Seleccion)
	//Getter de Rol
	public String getRol() {
		return Rol;
	}
	//Setter de Rol
	public void setRol(String rol) {
		Rol = rol;
	}
	
}
