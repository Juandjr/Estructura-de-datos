package main;
import java.util.Scanner;

//Main del programa hecho por Juan J
public class Main {

	public static void main(String[] args) {
		//declarando los atributos
		int opc;
		Scanner x = new Scanner(System.in);
		Entrenador entre = new Entrenador();
		Masajista masaj = new Masajista();
		Futbolista futbo = new Futbolista();
		//Mostrar el menu de opciones
		System.out.println("===Programa visor de Seleccion===");
		System.out.println("======== Menu de opciones========");
		System.out.println("1. Entrenador");
		System.out.println("2. Futbolista");
		System.out.println("3. Masajista");
		System.out.println("4. Salir");
		opc = x.nextInt();
		//realizar el bucle "While" para que el programa solo cierre en caso de seleccionar el boton de salir
		while (opc != 4) {
			//Switch que es el que nos permite crear el menu de opciones
			switch (opc){
			//caso 1 osea el del entrenador
			case 1:
				System.out.println("El entrenador recibe un pago de: "+entre.Pago);
				System.out.println("El entrenador a dirigido un total de: "+entre.partDirig+" Partidos digidos");
				System.out.println("Las victorias del equipo durante el mandato del entrenador actual es de: "+entre.Victorias);
				System.out.println("Las derrotas del equipo durante el mandato del entrenador actual es de: "+entre.Derrotas);
				System.out.println("El rol que cumple es de: "+entre.getRol());
				break;
			case 2:
				
				break;
			case 3:
				System.out.println("Cada masajista recibe un pago de: "+masaj.Pago);

				break;
			}
			System.out.println("===Programa visor de Seleccion===");
			System.out.println("======== Menu de opciones========");
			System.out.println("1. Entrenador");
			System.out.println("2. Futbolista");
			System.out.println("3. Masajista");
			System.out.println("4. Salir");
			opc = x.nextInt();
		}
		System.out.println("Gracias por ingresar 🥶");

	}

}
