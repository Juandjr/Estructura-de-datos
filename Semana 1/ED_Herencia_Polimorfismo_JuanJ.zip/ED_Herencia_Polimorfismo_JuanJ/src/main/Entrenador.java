package main;
//Clase hijas de la clase Seleccion
public class Entrenador extends Seleccion {
	//atributos de la clase
	double Pago = 2000;
	int partDirig = 15;

	//Constructor de los atributos de la clase Entrenador
	//Getter de Pago
	public double getPago() {
		return Pago;
	}
	//Setter de Pago
	public void setPago(double pago) {
		this.Pago = pago;
	}
	//Getter de Partidos Dirigidos
	public int getPartDirig() {
		return partDirig;
	}
	//Setter de Partidos Dirigidos
	public void setPartDirig(int partDirig) {
		this.partDirig = partDirig;
	}
	//Constructor de los atributos que hereda de la clase padre (Seleccion)
	//Getter de Victorias
	public int getVictorias() {
		return Victorias;
	}
	//Setter de victorias
	public void setVictorias(int victorias) {
		Victorias = victorias;
	}
	//Getter de Derrotas 
	public int getDerrotas() {
		return Derrotas;
	}
	//Setter de Derrotas
	public void setDerrotas(int derrotas) {
		Derrotas = derrotas;
	}
	//Setter de Rol
		public void setRol(String rol) {
			rol = "Entrenador";
			Rol = rol;
		}
	//Getter de Rol
	public String getRol() {
		return Rol;
	}
	
}
