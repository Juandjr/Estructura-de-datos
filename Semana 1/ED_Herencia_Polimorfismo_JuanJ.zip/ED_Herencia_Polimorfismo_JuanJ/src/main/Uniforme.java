package main;
//Clase hijas de la clase Futbolista
public class Uniforme extends Futbolista {
	String Color;
	String Material;
	String dueño;
	//Getter de Color
	public String getColor() {
		return Color;
	}
	//Setter de Color
	public void setColor(String color) {
		Color = color;
	}
	//Getter de Material
	public String getMaterial() {
		return Material;
	}
	//Setter de Material
	public void setMaterial(String material) {
		Material = material;
	}
	//Getter de Dueño
	public String getDueño() {
		return dueño;
	}
	//Setter de Dueño
	public void setDueño(String dueño) {
		this.dueño = dueño;
	}
	//Constructor de los atributos que hereda de la clase padre (Futbolista)
	//Getter de Tipo Jugador
	public String getTipoJugador() {
		return TipoJugador;
	}
	//Setter de Tipo Jugador
	public void setTipoJugador(String tipoJugador) {
		TipoJugador = tipoJugador;
	}
	
}
