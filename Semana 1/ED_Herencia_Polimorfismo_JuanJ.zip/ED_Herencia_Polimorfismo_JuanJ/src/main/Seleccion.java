package main;

public class Seleccion {
	int Victorias = 10;
	int Derrotas = 5;
	double Ganancias =250000;
	String Rol =;
	
	//Constructor de los atributos de la clase Seleccion
	//Getter de victorias 
	public int getVictorias() {
		return Victorias;
	}
	//Setter de victorias
	public void setVictorias(int victorias) {
		Victorias = victorias;
	}
	//Getter de Derrotas 
	public int getDerrotas() {
		return Derrotas;
	}
	//Setter de Derrotas
	public void setDerrotas(int derrotas) {
		Derrotas = derrotas;
	}
	//Getter de Ganancias
	public double getGanancias() {
		return Ganancias;
	}
	//Setter de Ganancias
	public void setGanancias(double ganancias) {
		Ganancias = ganancias;
	}
	//Getter de Rol
	public String getRol() {
		return Rol;
	}
	//Setter de Rol
	public void setRol(String rol) {
		Rol = rol;
	}
	
}
