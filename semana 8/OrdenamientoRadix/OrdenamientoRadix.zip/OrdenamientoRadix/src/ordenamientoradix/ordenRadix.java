package ordenamientoradix;//nos indica que esta en la libreria ordenaminetoRadix

import java.util.LinkedList;//dice que usa la libreria de listasEnlazadas que nos permite ocupar las funciones de estas 
import java.util.Queue;//dice que usa la libreria de colas y nos deja usar los metodos unicos para este tipos de TDA

public class ordenRadix {//Inicio de la clase ordenRadix
    public static int[] ordenacionRadix(int[] vec) {//inicio del metodo statico entero ordenacion Radix que contiene el valor vec que es un array
        int rep = 1; // cantidad de repeticiones
        int numBytes = 4; // número de bytes a desplazar
        int numColas = (int) Math.pow(2, numBytes);
        
        // Creación de las colas
        Queue[] cola = new LinkedList[numColas];
        for (int i = 0; i < numColas; i++) {//for que nos dice que recorre la cola donde cada repeticion realiza dentro de la cola una lista enlazada
            cola[i] = new LinkedList();
        }
        int div = 0;//declara un valor denominado div de tipo entero y lo inicializa con 0
        for (int i = 0; i < rep; i++) {
            // En esta parte recorre el vector para guardar cada valor en la cola
            for (int numero : vec) {
                // Busca el mayor número del vector
                if (i == 0) {
                    if (numero > rep) {
                        rep = numero;
                    }
                }
                // Calcula en que cola debe ir cada número
                int numCola = (numero >> div) & 0xf;
                cola[numCola].add(numero);
            }
            div = div + numBytes;
            // Recorre cada cola para colocar cada elemento en el vector
            int j = 0;
            for (Queue c : cola) {
                while (!c.isEmpty()) {
                    vec[j++] = (int) c.remove();
                }
            }
            // La primera vez se actualiza el número de veces que debe ejecutar el proceso
            if (i == 0) {
                rep = (int) (Math.log(rep) / Math.log(numColas)) + 1;
            }
        }
        
        return vec;//regresa el valor de vec
    }//fin del metodo ordenacionRadix
    
    public static void imprimirVector(int vec[]){
        //for que repite hasta que i recorra el vector hasta que el vector no durante i no sea igual o mayor al tamaño del array vec[]
        for(int i=0;i<vec.length;i++){
            System.out.print(vec[i]+" ");//muestra en pantalla el valor dentro del array vec[i] y lo que este dentro de la posicion i
        }
    }//fin del metodo imprimirVector
}//fin de la clase ordenRadix
