
package ordenamientoradix;//nos indica que esta en la libreria ordenaminetoRadix
/**
 *
 * @author jrome
 */
public class OrdenamientoRadix {//inicio de la clase OrdenamientoRadix

    public static void main(String args[]){//metodo que inicializa el programa 
        ordenRadix radix = new ordenRadix();//creacion de la instancia radix de la clase ordenRadix
        int vec[]={45,17,23,67,21, 44, 12,34};//creacion del vector de tipo entero que se uso de ejemplo con los valores dentro de las llaves
        System.out.println("Vector original");//se muestra en pantalla un mensaje que dice Vector original
        radix.imprimirVector(vec);//realiza la llamada al metodo de la clase ordenRadix que imprime los datos del array
        System.out.println("\nVector ordenado");//muestra en pantalla un mensaje que dice Vectro ordenado
        vec= ordenRadix.ordenacionRadix(vec);//una variable vec va a tomar el valor devuelto del metodo ordenacionRadix()
        radix.imprimirVector(vec);//se vuelve a llamar al metodo imprimirVector para mostrar los datos ordenados
    }//fin del metodo main
    
}//fin de la clase prinicpal OrdenaminetoRadix
