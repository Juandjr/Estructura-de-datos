//paquete en el cual se encuentra el programa
package busquedabinariapresentacion;
import javax.swing.SwingUtilities;//libreria que nos permite hacer uso de la utilidades de la libreria Swing

/**
 *
 * @author jrome
 */
//clase principal de la BusquedaBinariaPresientacion
public class BusquedaBinariaPresentacion { //esta es la clase publica de BusquedaBinaria
    //esta es el metodo statico void que realiza la funcion de ejecutar el programa
    public static void main(String[] args) {//inicio del metodo main que ejecuta el programa
        SwingUtilities.invokeLater(new Runnable(){//nos dice que con la libreria SwingUtilities crea un nuevo ejecutable
        @Override
        public void run(){//metodo que con ayuda de la libreria ejecuta lo siguiente
            new Ordenarxd();//esto dice que crea una ventana con el contenido de la clase Ordenarxd()
        }//fin del metodo run()
    });//fin del SwuingUtilities
    }//fin del metodo main
}//fin de la clase BusquedaBinariaPresentacion
   
