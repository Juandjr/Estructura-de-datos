package busquedabinariapresentacion;// esta linea nos dice que esta clase se encuentra en el paquete busquedabinariapresentacion
import java.awt.event.ActionEvent;//Importe de la libreria ActionEvent que nos sirve para dar haciones a los botones de la aplicacion
import java.awt.event.ActionListener;//Importe de la libreria que nos permite hacer que los botones llamen a una accion 
import javax.swing.*;//importe que nos permite usar todos los metodos de la clase Swing que como ejemplo estan el JButton y JTextArea

public class Ordenarxd extends JFrame {//inicio de la clase Ordenarxd que extiende la clase JFrame que viene en java 
    private JTextField InputField;//declaracion de las variables que se van a usar como el JTextField para poner el texto
    private JButton addButton;//el JButton para añadir botones al programa
    private JButton simularButton;
    private JButton buscaButton;
    private JTextArea resultArea;//JTextArea para el mostrar los datos en una tabla
    Radix radix = new Radix();//llamada a la clase Radix con una instancia radix
    private int[] numbers;//dato privado de tipo entero el cual es el array numbers
    int resultado;//dato de tipo entero resultado

    public Ordenarxd(){//metodo Ordenarxd o el constructor de este
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//esta nos dice que la operacion por defecto es cerrar el programa
        setTitle("Ordenamiento Radix y Busqueda Binaria JuanJ");//Esta linea nos sirve para poner el titulo del programa
        setSize(500,300);//El tamaño del programa donde 500 es el ancho y 300 es el alto
        setLayout(null);//que el fondo sea nulo 
        InputField = new JTextField();//constructor de los datos anteriormente mostrados donde se les añade un nombre
        addButton = new JButton("Añadir");
        simularButton = new JButton("Ordenar");
        buscaButton = new JButton("Busqueda");
        resultArea = new JTextArea();
        
        InputField.setBounds(20,20,150,30);//estas nos dice que los valores anteriormente van a tener el tamaño y estara en la ubicacion
        addButton.setBounds(180, 20, 90, 30);
        simularButton.setBounds(280, 20, 90, 30);
        buscaButton.setBounds(380, 20, 90,30);
        resultArea.setBounds(20, 70, 350, 150);
        resultArea.setEditable(false);
        numbers= new int[0];// constructor del array numbers
        addButton.addActionListener(new ActionListener() {//metodo que sirve para darle una funcion al boton addButton
            @Override
            public void actionPerformed(ActionEvent e) {//metodo que sirve para realizar la funcion dentro de las llaves
                addNumero();//llamada al metodo addNumero();
            }//fin del metodo actionPerformed
        });//fin del metodo addButton.addActionListener
        
        simularButton.addActionListener(new ActionListener() {//metodo que sirve para darle una funcion al boton simularButton
            @Override
            public void actionPerformed(ActionEvent e) {//metodo que sirve para realizar la funcion dentro de las llaves
                simulateBubbleSort();//llamada al metodo sumulateBubbleSort();
            }//fin del metodo actionPerformed
        });//fin del metodo simularButton.addActionListener
        
        buscaButton.addActionListener(new ActionListener() {//metodo que sirve para darle una funcion al boton buscaButton
            @Override
            public void actionPerformed(ActionEvent e) {//metodo que sirve para realizar la funcion dentro de las llaves
                int xd = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número a buscar"));//aqui el valor entero xd va a tomar el valor ingresado en la ventana 
                resultado = busquedaBinaria(numbers,xd);//resultado va a tomar el valor del metodo busquedaBinaria 
                resultBusqueda();//metodo que muestran los resultados de la busqueda
            }//fin del metodo actionPerformed
        });//fin del metodo buscaButton.addActionListener
        
        add(resultArea);//add() significa que se añade lo que este dentro a la ventana principal
        add(InputField);
        add(addButton);
        add(simularButton);
        add(buscaButton);

        
        setVisible(true);//esta linea hace que se vuelva visible la ventana del programa
    }//fin del constructor 
    
    private void addNumero(){//metodo addNumero que nos permite añadir numeros al programa
        try{//indica que este intente realizar lo siguiente
            int number= Integer.parseInt(InputField.getText());// hace que el valor number de tipo entero tome el valor de lo que el usuario ingrese dentro de la ventana
            InputField.setText("");//esta linea dice que el InputField estara vacio 
            if(numbers==null){//si numbers esta vacio
                numbers = new int[]{number};//numbers sera igual a number
            }else{//si no 
            int[] newArray = new int[numbers.length+1];//se creara un nuevo array que tomara el valor del tamaño de numbers + 1
            System.arraycopy(numbers, 0, newArray, 0, numbers.length);//linea que pega los datos del array en la tabla
            newArray[numbers.length]=number;//el array newArray toma el valor de number en la posicion del tamaño del array numbers
            numbers=newArray;//numbers sera igual a newArray
            }//fin del else
            updateResultArea();//metodo que recarga la tabla de resultados
            //
        }catch(NumberFormatException e){//catch dice que si el programa tiene un error realize lo siguiente
            JOptionPane.showMessageDialog(this, "Error al ingresar un Numero","Error",JOptionPane.ERROR_MESSAGE);//aqui muestra en una ventana de error
        }//fin del catch
    }//fin del metodo addNumero()
    
    private void simulateBubbleSort(){//metodo que representa el radixsort
        if(numbers !=null&& numbers.length > 1){//si el array number no es nulo y el tamaño del array es mayor a 1 hacer lo siguiente
            Radix.ordenacionRadix(numbers);//llama de la clase Radix el metodo ordenacionRadix y con el array numbers
            updateResultArea();//metodo que actualiza la tabla 
        }else{//sino realizar lo siguiente
            JOptionPane.showMessageDialog(this, "Agregue al menos dos numeros antes de simular el ordenamiento.", "Advertencia", JOptionPane.WARNING_MESSAGE);//mensaje de error en caso de no cumplir lo anterior
        }//fin del else
    }//fin del metodo simulateBubbleSort()
    
    public int busquedaBinaria(int elementos[], int x){//Este método toma como parámetros un arreglo de elementos        
           //ordenados y un valor a buscar, y devuelve la posición del valor en el arreglo o -1 si no se encuentra.
        //declaracion y inicializacion de las variables donde elementos[] es el array utilizado y x es el valor separado
        int l = 0, r = elementos.length - 1; //l inicializa en 0 y r en la cantidad de elementos del array menos uno
                                    //l significa Left (izquierda) osea el valor de la posicion inicial del array
                                    //r significa Right (derecha) osea el valor de la posicion del tamaño del array menos 1
        while (l <= r) {// buque while (mientras) que nos dice que va a seguir haciendose mientras l sea menor o igual a r
            //se declara un valor entero "m" que sera igual a la operacion l + (r - l) / 2
            int m = l + (r - l) / 2;
            //un if que nos dice que devolvera verdadero si la posicion m del array sea igual a x
            if (elementos[m] == x)
                //en caso de ser positivo el valor regresado sera m
                return m;
            //if que nos dice que en caso de que el valor de la posicion de m del array sea menor que x 
            if (elementos[m] < x)
                //este hara que l sea igual al valor de m + 1
                l = m + 1;
            // else (demas) que nos dice que si el ultimo if que se realizo tambien debe realizar
            else
                //Que r tome el valor de m - 1
                r = m - 1;
        }
        //al cerrar el bucle while este retornara el valor de -1 y si ninguna de las otras funciones se cumplia se retorna
        return -1;
    }//fin del metodo busqueda binaria
    
    private void updateResultArea(){//Metodo que actualiza la tabla de resultArea
        StringBuilder sb = new StringBuilder();//un StringBuilder que crea una instancia sb
        sb.append("Numeros: ");//este dice que el string sb va a tener la forma base Numeros:
        for(int num:numbers){//for que dice que el valor num va a tomar el valor de numbers
            sb.append(num).append(" ");//esta linea agrega a sb el num y que se va a separar " "
        }//fin del for
        resultArea.setText(sb.toString());//se añade al resultArea el texto de sb.toString()
    }//fin del metodo updateResultArea()
    
    public static void imprimirVector(int vec[]){//metodo que imprime el vector / array
        for(int i=0;i<vec.length;i++){//for que recorre el array 
            System.out.print(vec[i]+" ");//imprime en consola el contenido del array
        }//fin del for
    }//fin del metodo imprimirVector()
    
    private void resultBusqueda(){//metodo que muestra el resultBusqueda
        if (resultado == -1)//if que verifica que resultado no sea igual a -1
            System.out.println("No se ha encontrado el elementos buscado");//muestra en consola que no se encontro el elemento buscado
        else//sino 
            System.out.println("Elemento encontrado en la posicion: "+ resultado );//muestra que es en contro el elemento y la posicion en el que esta               
    }//fin del metodo resultBusqueda()
}//fin de la clase Ordenarxd
