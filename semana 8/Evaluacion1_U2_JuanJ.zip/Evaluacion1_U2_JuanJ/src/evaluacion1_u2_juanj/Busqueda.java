package evaluacion1_u2_juanj;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.awt.image.ImageObserver.HEIGHT;
import javax.swing.*;

public class Busqueda extends JFrame {
    private JTextField InputField;
    private JButton addButton;
    private JButton simularButton;
    private JButton buscaButton;
    private JTextArea resultArea;
    private JLabel text;
    private JLabel text1;
    private int[] numbers;

    public Busqueda(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Ordenamiento Burbuja Evaluacion JuanJ");
        setSize(500,400);
        setLayout(null);
        InputField = new JTextField();
        addButton = new JButton("Añadir");
        simularButton = new JButton("Simular");
        buscaButton = new JButton("Ordenar");
        resultArea = new JTextArea();
        text = new JLabel("=====Ingresar estudiante======");
        text1 = new JLabel("Ingresar Nota");
        text.setBounds(150, 10, 300, 30);
        text1.setBounds(50, 15, 300, 30);
        InputField.setBounds(20,50,150,30);
        
        addButton.setBounds(180, 50, 90, 30);
        simularButton.setBounds(280, 50, 90, 30);
        resultArea.setBounds(20, 90, 400, 200);
        resultArea.setEditable(false);
        numbers= new int[0];
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNumero();
            }
        });
        
        simularButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                simulateBubbleSort();
            }
        });
        
        buscaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                simulateBusqueda();
            }
        });
        add(text);
        add(text1);
        add(resultArea);
        add(InputField);
        add(addButton);
        add(simularButton);

        
    }
    
    private void addNumero(){
        try{
            int number= Integer.parseInt(InputField.getText());
            InputField.setText("");
            if(numbers==null){
                numbers = new int[]{number};
            }else{
            int[] newArray = new int[numbers.length+1];
            System.arraycopy(numbers, 0, newArray, 0, numbers.length);//linea que pega los datos del array en la tabla
            newArray[numbers.length]=number;
            numbers=newArray;
            }
            updateResultArea();
            //
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "Error al ingresar un Numero","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
    private void simulateBubbleSort(){
        if(numbers !=null&& numbers.length > 1){
            Burbuja.sort(numbers);
            updateResultArea();
        }else{
            JOptionPane.showMessageDialog(this, "Agregue al menos dos numeros antes de simular el ordenamiento.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
        
    }
    
    private void simulateBusqueda(){
        int dato,infe,sup,mitad,i;
  boolean bandera =false;
  //pedir el número a buscar
  dato= Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número a buscar"));
  //CODIGO DE BEUSQUEDA binaria
 infe=0;
 sup=5;
 i=0;
 mitad=(infe+sup)/2;
  while (infe<sup && i<5){
      if(numbers[mitad]==dato){
          bandera=true;
          break;
      }
     if(numbers[mitad]>dato){
         sup=mitad;
         mitad=(infe+sup)/2;
     }
          if(numbers[mitad]<dato){
         infe=mitad;
         mitad=(infe+sup)/2;
     }
          i++;}
  if (bandera ==true){
      JOptionPane.showMessageDialog(null, "EL NUMERO  SE ENCUENTRA EN EL ARREGLO"+mitad);
      
  }else{
      JOptionPane.showMessageDialog(null, "EL NUMERO  no SE ENCUENTRA EN EL ARREGLO");
      
  }
    }
    
    private void updateResultArea(){
        StringBuilder sb = new StringBuilder();
        StringBuilder name = new StringBuilder();
        name.append("Nombre: ");
        for(int nam:numbers){
            name.append(nam).append(" ");
        }
        sb.append("Notas: \n");
        for(int num:numbers){
            sb.append(num).append(" ");
            
        }
        resultArea.setText(sb.toString());
    }
    
    
}
