package evaluacion1_u2_juanj;

import javax.swing.SwingUtilities;

public class Evaluacion1_U2_JuanJ {

    public static void main(String[] args) {//inicio del metodo main que ejecuta el programa
        SwingUtilities.invokeLater(new Runnable(){//nos dice que con la libreria SwingUtilities crea un nuevo ejecutable
        @Override
        public void run(){//metodo que con ayuda de la libreria ejecuta lo siguiente
            new MenuPrincipal();//esto dice que crea una ventana con el contenido de la clase Ordenarxd()
        }//fin del metodo run()
    });//fin del SwuingUtilities
    }//fin del metodo main
    
}
