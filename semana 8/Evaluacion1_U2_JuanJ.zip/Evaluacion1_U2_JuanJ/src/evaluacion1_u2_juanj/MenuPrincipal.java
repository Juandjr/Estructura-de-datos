
package evaluacion1_u2_juanj;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class MenuPrincipal extends JFrame {
    private JTextField InputField;
    private JButton ingreButton;
    private JButton salirButton;
    private JTextArea resultArea;
    private JLabel text;
    private JLabel text1;
    private JLabel text3;
    OrdenarBurbuja burbujaingre = new OrdenarBurbuja();
    
    private int[] numbers;

    public MenuPrincipal(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Evaluacion 1 U2 JuanJ");
        setSize(600,400);
        setLayout(null);
        InputField = new JTextField();
        ingreButton = new JButton("Ingresar");
        salirButton = new JButton("Salir");
        text = new JLabel("==========MENU PRINCIPAL==========");
        text1 = new JLabel("Pulse el boton Ingresar para ingresar los datos del estudiante");
        text3 = new JLabel("Pulse el boton de salir para cerrar el programa");
        resultArea = new JTextArea();
        
        InputField.setBounds(20,20,150,30);
        text.setBounds(150, 20, 300, 30);
        text1.setBounds(100, 70, 500, 30);
        text3.setBounds(100, 110, 500, 30);
        ingreButton.setBounds(75, 200, 100, 50);
        salirButton.setBounds(225, 200, 100, 50);
        numbers= new int[0];
        ingreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable(){//nos dice que con la libreria SwingUtilities crea un nuevo ejecutable
                    @Override
                    public void run(){//metodo que con ayuda de la libreria ejecuta lo siguiente
                        new OrdenarBurbuja();//esto dice que crea una ventana con el contenido de la clase OrdenarBurbuja()
                        burbujaingre.setVisible(true);
                        dispose();
                    }//fin del metodo run()
                });//fin del SwuingUtilities
            }
        });
        
        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                burbujaingre.dispose();
            }
        });

        add(text);
        add(text1);
        add(text3);
        add(ingreButton);
        add(salirButton);

        
        setVisible(true);
    }

}

