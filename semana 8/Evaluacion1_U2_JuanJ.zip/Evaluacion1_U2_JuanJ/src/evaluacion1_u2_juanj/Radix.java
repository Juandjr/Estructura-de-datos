
package evaluacion1_u2_juanj;
import java.util.LinkedList;
import java.util.Queue;

public class Radix {
    public static int[] ordenacionRadix(int[] vec) {
        int rep = 1; // cantidad de repeticiones
        int numBytes = 4; // número de bytes a desplazar
        int numColas = (int) Math.pow(2, numBytes);
        
        // Creación de las colas
        Queue[] cola = new LinkedList[numColas];
        for (int i = 0; i < numColas; i++) {
            cola[i] = new LinkedList();
        }
        int div = 0;
        for (int i = 0; i < rep; i++) {
            // En esta parte recorre el vector para guardar cada valor en la cola
            for (int numero : vec) {
                // Busca el mayor número del vector
                if (i == 0) {
                    if (numero > rep) {
                        rep = numero;
                    }
                }
                // Calcula en que cola debe ir cada número
                int numCola = (numero >> div) & 0xf;
                cola[numCola].add(numero);
            }
            div = div + numBytes;
            // Recorre cada cola para colocar cada elemento en el vector
            int j = 0;
            for (Queue c : cola) {
                while (!c.isEmpty()) {
                    vec[j++] = (int) c.remove();
                }
            }
            // La primera vez se actualiza el número de veces que debe ejecutar el proceso
            if (i == 0) {
                rep = (int) (Math.log(rep) / Math.log(numColas)) + 1;
            }
        }
        return vec;
    }
}
