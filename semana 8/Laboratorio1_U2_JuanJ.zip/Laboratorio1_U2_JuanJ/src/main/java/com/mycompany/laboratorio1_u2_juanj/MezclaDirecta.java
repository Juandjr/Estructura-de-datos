/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.laboratorio1_u2_juanj;

/**
 *
 * @author jrome
 */
public class MezclaDirecta {
    public static void mezclaDirecta(int[] vec) {
        if (vec.length <= 1) return;
        int mitad = vec.length / 2;
        int[] izq = new int[mitad];
        int[] der = new int[vec.length - mitad];
        for (int i = 0; i < mitad; i++) {
            izq[i] = vec[i];
        }
        for (int i = mitad; i < vec.length; i++) {
            der[i - mitad] = vec[i];
        }
        mezclaDirecta(izq);
        mezclaDirecta(der);
        int i = 0;
        int j = 0;
        int k = 0;
        while (i < izq.length && j < der.length) {
            if (izq[i] < der[j]) {
                vec[k] = izq[i];
                i++;
            } else {
                vec[k] = der[j];
                j++;
            }
            k++;
        }
        while (i < izq.length) {
            vec[k] = izq[i];
            i++;
            k++;
        }
        while (j < der.length) {
            vec[k] = der[j];
            j++;
            k++;
        }
    }
}