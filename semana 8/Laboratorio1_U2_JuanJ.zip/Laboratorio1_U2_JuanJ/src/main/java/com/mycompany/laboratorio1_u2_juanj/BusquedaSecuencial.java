/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.laboratorio1_u2_juanj;

/**
 *
 * @author jrome
 */
public class BusquedaSecuencial {
    public static int busquedaSecuencial(int[] vec, int valor) {
        for (int i = 0; i < vec.length; i++) {
            if (vec[i] == valor) {
                return i;
            }
        }
        return -1;
    }
}
