
package com.mycompany.laboratorio1_u2_juanj;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class IngresoPeriodo extends JFrame {
    private JTextField InputField;
    private JTextField InputField1;
    private JTextField InputField2;
    private JButton addButton;
    private JButton editarButton;
    private JButton borrarButton;
    private JButton salirButton;
    private JTable resultArea;
    private DefaultTableModel modeloTabla;
    private JLabel text;
    private JLabel text1;
    private JLabel text2;
    private JLabel text3;
    private JLabel fondo;
    private String[] periodo;
    private String[] carrera;
    private String[] curso;
    
    int resultado;
    String connectionString = "mongodb://localhost:27017"; // Reemplaza con tu conexión a MongoDB

    public IngresoPeriodo(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Ingreso Periodo JuanJ");
        setSize(750,500);
        setLayout(null);
        InputField = new JTextField();
        InputField1 = new JTextField();
        InputField2 = new JTextField();
        addButton = new JButton("Añadir");
        editarButton = new JButton("Editar");
        salirButton = new JButton("Volver");
        borrarButton = new JButton("Borrar");
        modeloTabla = new DefaultTableModel();
        fondo = new JLabel("");
        ImageIcon imagen = new ImageIcon("fondoperi.jpg");
        fondo.setBounds(0, 0, 750, 500);
        fondo.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(fondo.getWidth(), fondo.getHeight(), Image.SCALE_SMOOTH)));
        resultArea = new JTable();
        text = new JLabel("<html><b>======Ingresar Periodo======<b></html>");
        text1 = new JLabel("<html><b>Periodo:<b></html>");
        text2 = new JLabel("<html><b>Carrera:<b></html>");
        text3 = new JLabel("<html><b>Curso:<b></html>");
        text.setBounds(220, 5, 500, 30);
        text.setFont(new Font("arial",Font.PLAIN,20));
        text.setForeground(Color.BLACK);
        text1.setBounds(20, 100, 300, 30);
        text1.setFont(new Font("arial",Font.PLAIN,12));
        text1.setForeground(Color.BLACK);
        text2.setBounds(20, 150, 300, 30);
        text2.setFont(new Font("arial",Font.PLAIN,12));
        text2.setForeground(Color.BLACK);
        text3.setBounds(20, 200, 300, 30);
        text3.setFont(new Font("arial",Font.PLAIN,12));
        text3.setForeground(Color.BLACK);
        InputField.setBounds(75,100,220,30);
        InputField1.setBounds(75,150,220,30);
        InputField2.setBounds(75,200,220,30);
        salirButton.setBounds(10, 300, 80, 30);
        addButton.setBounds(110, 300, 80, 30);
        borrarButton.setBounds(210, 300, 80, 30);
        editarButton.setBounds(50, 350, 80, 30);
        resultArea.setBounds(320, 50, 380, 380);
        periodo= new String[0];
        curso = new String[0];
        carrera= new String[0];
        
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNumero();
            }
        });
        
        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });
        
        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MenuPrincipal();
                dispose();
            }
        });
        
        borrarButton.addActionListener(new ActionListener() {//metodo que sirve para darle una funcion al boton buscaButton
            @Override
            public void actionPerformed(ActionEvent e) {//metodo que sirve para realizar la funcion dentro de las llaves
                int xd = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número a buscar"));//aqui el valor entero xd va a tomar el valor ingresado en la ventana 
            }//fin del metodo actionPerformed
        });//fin del metodo buscaButton.addActionListener
        
        
        
        setLocationRelativeTo(null);
        add(text);
        add(text1);
        add(text2);
        add(text3);
        add(resultArea);
        add(InputField);
        add(InputField1);
        add(InputField2);
        add(addButton);
        add(salirButton);
        add(borrarButton);
        add(editarButton);
        add(fondo);

        
    }
    
    private void addNumero() {
        String perio = InputField.getText();
        InputField.setText("");
        if (periodo == null) {
            periodo = new String[]{perio};
        } else {
            String[] newArray = new String[periodo.length + 1];
            System.arraycopy(periodo, 0, newArray, 0, periodo.length);
            newArray[periodo.length] = perio;
            periodo = newArray;
        }
        String carr = InputField1.getText();
            InputField1.setText("");
            if(carrera==null){
                carrera = new String[]{carr};
            }else{
            String[] newArray = new String[carrera.length+1];
            System.arraycopy(carrera, 0, newArray, 0, carrera.length);//linea que pega los datos del array en la tabla
            newArray[carrera.length]= carr;
            carrera=newArray;
            }
        updateResultArea();
    }

    
    private void updateResultArea(){
        StringBuilder sb = new StringBuilder();
        StringBuilder carre = new StringBuilder();
        sb.append("Periodo: \n");
        for(String peri:periodo){
            sb.append(peri).append(" ");
        }
        carre.append("Carrera: \n");
        for(String carrer:carrera){
            carre.append(carrer).append(" ");
            
        }
    }

}
