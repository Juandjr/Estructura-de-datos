
package practica1_2daunidad_juanj_burbuja;

import java.util.Arrays;

public class Burbuja {
        static void sort(String[] arr) {
        Arrays.sort(arr);
    }
}

