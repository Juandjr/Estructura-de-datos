
package practica1_2daunidad_juanj_burbuja;
import javax.swing.*;

public class Ordenar_Burbuja extends JFrame {
    public static void main(String[] args){
        SwingUtilities.invokeLater(new Runnable(){
        @Override
        public void run(){
            new OrdenarBurbuja();
        }
    });
    }
}
