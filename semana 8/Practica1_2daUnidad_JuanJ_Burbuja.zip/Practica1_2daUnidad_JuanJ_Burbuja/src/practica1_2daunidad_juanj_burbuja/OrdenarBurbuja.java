
package practica1_2daunidad_juanj_burbuja;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.awt.image.ImageObserver.HEIGHT;
import javax.swing.*;

public class OrdenarBurbuja extends JFrame {
    private JTextField InputField;
    private JButton addButton;
    private JButton simularButton;
    private JTextArea resultArea;
    
    private int[] numbers;

    public OrdenarBurbuja(){
        numbers= new int[0];
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNumero();
            }
        });
        
        simularButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                simulateBubbleSort();
            }
        });
    }
    
    public void iniciarB(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Ordenamiento Burbuja JuanJ");
        setSize(1280,720);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        JTextField InputField = new JTextField();
        JButton addButton = new JButton("Añadir");
        JButton simularButton = new JButton("Simular");
        JTextArea resultArea = new JTextArea();
        JLabel numero = new JLabel("Numero: ");
        resultArea.setEditable(true);
        
        numero.setHorizontalAlignment(HEIGHT);
        numero.setFont(new Font("arial",Font.PLAIN,15));
        numero.setBounds(50, 60, 350, 50);
        numero.setForeground(Color.red);
        
        
        panel.add(InputField);
        panel.add(addButton);
        panel.add(simularButton);
        panel.add(resultArea);
        panel.add(numero);
        panel.add(new JScrollPane(resultArea));
        
        add(panel);
    }
    
    private void addNumero(){
        try{
            int number= Integer.parseInt(InputField.getText());
            int[] newArray = new int[numbers.length+1];
            System.arraycopy(numbers, 0, newArray, 0, numbers.length);//linea que pega los datos del array en la tabla
            newArray[numbers.length]=number;
            numbers=newArray;
            InputField.setText("");
            updateResultArea();
            //
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "Error al ingresar un Numero","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void simulateBubbleSort(){
        Burbuja.sort(numbers);
        updateResultArea();
    }
    
    private void updateResultArea(){
        StringBuilder sb = new StringBuilder();
        for(int num:numbers){
            sb.append(num).append("");
        }
        resultArea.setText("Numeros Ingresados");
    }
    
}
