
package practica1_2daunidad_juanj_burbuja;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.awt.image.ImageObserver.HEIGHT;
import javax.swing.*;

public class OrdenarBurbuja extends JFrame {
    private JTextField InputField;
    private JButton addButton;
    private JButton simularButton;
    private JTextArea resultArea;
    
    private int[] numbers;

    public OrdenarBurbuja(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Ordenamiento Burbuja JuanJ");
        setSize(400,300);
        setLayout(null);
        InputField = new JTextField();
        addButton = new JButton("Añadir");
        simularButton = new JButton("Simular");
        resultArea = new JTextArea();
        
        InputField.setBounds(20,20,150,30);
        
        addButton.setBounds(180, 20, 90, 30);
        simularButton.setBounds(280, 20, 90, 30);
        resultArea.setBounds(20, 70, 350, 150);
        resultArea.setEditable(false);
        numbers= new int[0];
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNumero();
            }
        });
        
        simularButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                simulateBubbleSort();
            }
        });
        add(resultArea);
        add(InputField);
        add(addButton);
        add(simularButton);
        

        
        setVisible(true);
    }
    
    private void addNumero(){
        try{
            int number= Integer.parseInt(InputField.getText());
            InputField.setText("");
            if(numbers==null){
                numbers = new int[]{number};
            }else{
            int[] newArray = new int[numbers.length+1];
            System.arraycopy(numbers, 0, newArray, 0, numbers.length);//linea que pega los datos del array en la tabla
            newArray[numbers.length]=number;
            numbers=newArray;
            }
            updateResultArea();
            //
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "Error al ingresar un Numero","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void simulateBubbleSort(){
        if(numbers !=null&& numbers.length > 1){
            Burbuja.sort(numbers);
            updateResultArea();
        }else{
            JOptionPane.showMessageDialog(this, "Agregue al menos dos numeros antes de simular el ordenamiento.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
        
    }
    
    private void updateResultArea(){
        StringBuilder sb = new StringBuilder();
        sb.append("Numeros: ");
        for(int num:numbers){
            sb.append(num).append(" ");
        }
        resultArea.setText(sb.toString());
    }
    
    
}
