
package practica1_2daunidad_juanj_burbuja;

public class Burbuja {
    public static void main(String[] args) {
        // TODO code application logic here
        OrdenarBurbuja ordBur = new OrdenarBurbuja();
    }
}
