/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica3_juanj_2daunidad;

import java.util.Scanner;

/**
 *
 * @author ESPE
 */
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int opc;
        System.out.println("===Menu de Opciones===");
        System.out.println("1.Ordenacion Burbuja");
        System.out.println("2.Ordenacion Seleccion");
        System.out.println("3.Ordenacion Seleccion");
        System.out.println("4.Salir");
        opc = scan.nextInt();
        while(opc!=4){
            switch(opc){
                case 1:
                    // problema: calcular el maximo y el minimo valor de un conjunto de N datos
// variable que guarda los valores ingresados por el teclado
long datos;
// declaramos instancia de la clase Scanner para ingresar datos por la consola
Scanner entrada = new Scanner(System.in);
// ingresamos cantidad de datos a procesar
System.out.print("Ingrese la cantidad de datos a analizar: ");
int tamano=entrada.nextInt();
// creamos una instancia de la clase ArregloBurbuja (pasamos la variable tamaño al constructor)
ArregloBurbuja arr = new ArregloBurbuja(tamano);
// ingresamos conjunto de datos
System.out.println("Ingrese los " + tamano + " datos ");
// leemos los datos numericos ingresados por teclado
for(int i=0;i<tamano;i++) {
System.out.print("Dato " + (i + 1) + ": ");
datos=entrada.nextLong();
arr.insertar(datos);
}
// cerramos instancia de Scanner
entrada.close();
// imprimimos datos ingresados
System.out.println("Datos antes de estar ordenados:");
arr.mostrarElementos();
// ordenamos los datos usando la ordenacion por burbuja
arr.ordenacionBurbuja();
// imprimimos datos ordenados
System.out.println("Datos ordenados:");
arr.mostrarElementos();
// imprimimos elemento menor y mayor
System.out.println("El menor valor es: " + arr.valorElemento(0));
System.out.println("El mayor valor es: " + arr.valorElemento(tamano-1));
                    break;
                case 2:
                    /*
* Dado un conjunto de valores enteros, retornar todos las pares de n�meros
cuya diferencia sea igual a dos. El resultado deber�
* estar en orden ascendente de valores. Si se ingresan valores enteros
duplicados solo se considerar�n una vez para el c�lculo de
* las diferencias.
*/
/*
* Paso1: Ingreso de datos a analizar
*/
ArregloSeleccion arre=new ArregloSeleccion(10);
arre.insertar(11);
arre.insertar(3);
arre.insertar(1);
arre.insertar(9);
arre.insertar(3);
arre.insertar(15);
arre.insertar(1);
arre.insertar(5);
arre.insertar(5);
arre.insertar(13);
System.out.print("Se ingreso el siguiente conjunto de caracteres: ");
arre.mostrarElementos();
/*
* Paso 2: Buscamos pares de numeros que tengan una diferencia de dos
*/
System.out.print("Pares de Elementos:");
arre.mostrarParesOrdenados();
break;
                case 3:
/*
Dado un numero entero no negativo, retornarlo con sus digitos en orden
descendente
*/
ArregloShell arre;
// Ingresamos numero a analizar
Scanner scanner=new Scanner(System.in);
System.out.print("Ingrese numero entero: ");
int numero=scanner.nextInt();
scanner.close();
// contamos el numero de digitos
int n=numero;
int numDigitos=0;
while (n>0) {
n=n/10;
numDigitos++;
}
// obtenemos cada digito del numero y lo ingresamos al arreglo
long cociente;
long digito;
long temp=numero;
arre=new ArregloShell(numDigitos);
while(temp!=0) {
cociente=temp/10;
digito=temp-cociente*10;
arre.insertar(digito);
temp=cociente;
}
// ordenamos el arreglo usando la ordenacion Shell
arre.ordenacionShell();
// imprimimos valores de arreglo desde ultimo elemento hasta el primero
arre.mostrarElementosOrdenInverso();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        System.out.println("===Menu de Opciones===");
        System.out.println("1.Ordenacion Burbuja");
        System.out.println("2.Ordenacion Seleccion");
        System.out.println("3.Ordenacion Shell");
        System.out.println("4.Salir");
        opc = scan.nextInt();
        }
    }
}
