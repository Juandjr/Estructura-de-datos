
package busqueda_secuencial;

import javax.swing.JOptionPane;

public class BusquedaSecuencial {

    public static void main(String[] args) {
        // TODO code application logic here
        int tam=0;
        int datoIngre;
        int dato;
        boolean bandera = false;
        //Pedir la cantidad de datos que desea ingresar
        tam = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el tamaño del arreglo: "));
        //declaracion del arreglo que se va a utilizar
        int arreglo[] = new int[tam];
        ArregloBurbuja arr = new ArregloBurbuja(tam);
        //pedir al usuario que ingrese la cantidad de datos del arreglo
        for (int j=0;j<tam;j++){
            arreglo[j]= (datoIngre = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero "+(j+1)+": ")));
            arr.insertar(datoIngre);
        }
        //mostrar datos del arreglo
        System.out.println("Datos antes de estar ordenados:");
                    arr.mostrarElementos();
                    arr.ordenacionBurbuja();
                    System.out.println("Datos ordenados:");
                    arr.mostrarElementos();
        //pedir numero a buscar
        dato = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero a buscar"));
        //Codigo de busqueda secuencial
        //interador buscar el 2
        int i = 0;//este dato nos sirve para recorrer el arreglo
        while(i<5 && bandera==false){
            if(arreglo[i]==dato){
                bandera = true;
            }
            i++;
        }
        if(bandera ==false){
            JOptionPane.showMessageDialog(null,"El numero no se encuentra en el arreglo");
        }else{
            JOptionPane.showMessageDialog(null, "El numero se encuentra en el arreglo "+(i-1));
        }
        
    }
    
}
