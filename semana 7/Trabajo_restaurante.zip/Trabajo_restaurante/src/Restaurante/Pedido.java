package Restaurante;
//librerias que se usaron para la clase pedido
import java.util.LinkedList;
import java.util.Queue;
//inicio de la clase pedido
public class Pedido {
    //declaracion de las variables de la clase pedido
    int numPedido;
    String nombreCliente;
    Queue<Producto> productos = new LinkedList<Producto>();
    //constructor de la clase pedido
    public Pedido(int numPedido, String nombreCliente){
        this.nombreCliente = nombreCliente;
        this.numPedido = numPedido;
    }
    //metodo que nos sirve para ingresar el producto al restaurante
    public void agregarProducto(Producto prod){
        this.productos.add(prod);
        System.out.println("Producto a sido agregado existosamente");
    }
    //metodo que nos devuelve el pedido que se haya ingresado y nos devuelve el valor str que es el pedido
    public String getPedido(){
        String str = String.format("""
                     -----------------------------------
                     Pedido:  %d
                     Cliente: %s
                     -----------------------------------
                     """, numPedido, nombreCliente);
        
        for(Producto prod : productos){
            str += "Plato:    "  +prod.nombre + "\n";
            str += "Precio:   " + prod.precio + "\n";
            str += "Cantidad: " + prod.cantidad + "\n";
            str += "-----------------------------------" + "\n";
        }
        return str;
    }
}
