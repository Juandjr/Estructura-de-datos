package Restaurante;
//libreria que se usaron en la clase main 
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
//inicio de la clase principal
public class Main {
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        //declaracion de las variables que se utilizaran en la clase principal
        ArrayList<Producto> carta = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        Pedido ped;
        Restaurante res = new Restaurante();
        int opc, nPedido = 0, cantidad, option1;
        String priceStr, cantStr;
        String name, nombre;
        double price;
        Boolean esValido;
        //menu de opciones del programa 
        System.out.println("===Menu pricipal===");
        System.out.println("1. Agregar Productos");
        System.out.println("2. Agregar Pedido");
        System.out.println("3. Preparar Pedido");
        System.out.println("4. Entregar Pedido");
        System.out.println("5. Platillos en cocina");
        System.out.println("6. Platillos en comedor");
        System.out.println("0. Salir");
        opc = sc.nextInt();
        //bucle con el uso de while para la que el programa finalize cuando se seleccione salir
        while(opc!=0){
            //switch para realizar las distintas funciones
            switch (opc){
                case 1:
                    do{
                        System.out.print("Ingresar nombre del producto: ");
                        name = sc.nextLine();
                        esValido = name.matches("[a-zA-Z]+");

                        if(!esValido) System.out.println("INGRESE CARACTERES VALIDOS");
                    }while(!esValido);
                    
                    do{
                        System.out.print("Ingresar precio del producto: ");
                        priceStr = sc.nextLine();
                        esValido = priceStr.matches("\\d+(\\.\\d+)?");

                        if(!esValido) System.out.println("INGRESE CARACTERES VALIDOS");
                    }while(!esValido);
                    price = Double.parseDouble(priceStr);
                    
                    do{
                        System.out.print("Ingresar numero de productos disponibles: ");
                        cantStr = sc.nextLine();
                        esValido = cantStr.matches("\\d+");

                        if(!esValido){
                            System.out.println("INGRESE CARACTERES VALIDOS");
                        } else {
                            if(Integer.parseInt(cantStr) < 1) System.out.println("INGRESE UNA CANTIDAD VALIDA");;
                        }
                    }while(!esValido);
                    cantidad = Integer.parseInt(cantStr);
                    
                    carta.add(new Producto(name, price, cantidad));
                    break;
                case 2:
                    nPedido+=1;
                    do{
                        System.out.print("Ingrese el nombre de Cliente: ");
                        nombre = sc.nextLine();
                        esValido = nombre.matches("[a-zA-Z]+");
                        
                        if(!esValido) System.out.println("INGRESE CARACTERES VALIDOS");
                    }while(!esValido);
                    
                    ped = new Pedido(nPedido, nombre);
                    do{
                    System.out.println("1. Agregar producto");
                    System.out.println("2. Finalizar pedido");
                    System.out.println("0. Cancelar");
                    option1 = sc.nextInt();
                    sc.nextLine();
                        switch(option1){
                            case 1:
                                System.out.println("===Carta===");
                                for(Producto pro : carta){
                                    if(pro.cantidad!= 0){
                                        System.out.println(pro.getProducto());
                                    }else {
                                        carta.remove(pro);
                                    }
                                }
                                do{
                                    System.out.print("Ingrese su producto: ");
                                    nombre = sc.nextLine();
                                    esValido = nombre.matches("[a-zA-Z]+");

                                    if(!esValido) System.out.println("INGRESE CARACTERES VALIDOS");
                                }while(!esValido);
                                do{
                                    System.out.print("Ingresar cantidad de productos: ");
                                    cantStr = sc.nextLine();
                                    esValido = cantStr.matches("\\d+");
                                    
                                    if(!esValido) System.out.println("INGRESE CARACTERES VALIDOS");
                                }while(!esValido);
                                cantidad = Integer.parseInt(cantStr);
                                
                                
                                for(Producto pro : carta){
                                    if(pro.nombre.equals(nombre)){
                                        if(cantidad <= pro.precio){
                                            ped.agregarProducto(new Producto(pro.nombre, pro.precio, cantidad));
                                            
                                        }
                                    }
                                }
                                res.agregarPedido(ped.getPedido());
                                break;
                            case 2:
                                System.out.println("Pedido finalizado correctamente");
                                break;
                            default:
                                System.out.println("INGRESE UNA OPCION VALIDA");
                                break;
                                }
                    }while(option1 != 2 && option1 != 0);
                    break;
                case 3:
                    res.prepararPedido();
                    break;
                case 4:
                    try {
                        FileWriter fileWriter = new FileWriter("datosRest.txt");
                        fileWriter.write(res.pedidosPrep.peek());
                        fileWriter.close();
                    } catch (IOException e) {
                        System.out.println("Ocurrió un error al escribir en el archivo.");
                        e.printStackTrace();
                    }
                    res.entregarPedido();
                    break;
                case 5:
                    System.out.println("Platillos que se encuentran en la cocina: " + res.pedidosPend.size());
                    break;
                case 6:
                    System.out.println("Platillos en el comedor: " + res.pedidosPrep.size());
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        //para mostrar nuevamente el menu de opciones una vez se realize la opcion de un caso
        System.out.println("===Menu pricipal===");
        System.out.println("1. Agregar Productos");
        System.out.println("2. Agregar Pedido");
        System.out.println("3. Preparar Pedido");
        System.out.println("4. Entregar Pedido");
        System.out.println("5. Platillos en cocina");
        System.out.println("6. Platillos en comedor");
        System.out.println("0. Salir");
        opc = sc.nextInt();
        }
        //mensaje de finalizacion del programa
        System.out.println("Gracias por ingresar");
    }
}                      


