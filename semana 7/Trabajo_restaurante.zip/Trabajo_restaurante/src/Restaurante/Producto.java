package Restaurante;
//clase producto que es la clase que tiene como propocito la funcion de agregar productos al restaurante
public class Producto {
    //declaracion de metodos que se utilizaran en la clase producto
    String nombre;
    double precio;
    int cantidad;
    //constructor de la clase producto
    Producto(String nombre, double precio, int cantidad){
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
    //constructor de tipo string que nos devuelve el producto que se ingrese
    public String getProducto(){
        String prod = String.format("""
                                    Plato:    %s
                                    Precio:   %.2f
                                    Cantidad: %d
                                    """, nombre, precio, cantidad);
        
        return prod;
    }
}