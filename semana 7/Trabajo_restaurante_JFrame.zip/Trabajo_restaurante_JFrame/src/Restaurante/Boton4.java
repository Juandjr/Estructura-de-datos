
package Restaurante;

import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Boton4 extends JFrame{
    public Boton4(){
        setTitle("Add Product");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));
        
        JLabel Txt = new JLabel();
        
        Txt.setText("Se entrego el pedido correctamente");
        
        panel.add(Txt);
        
        add(panel);
        panel.setVisible(true);
    }
}
