package Restaurante;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddProductFrame extends JFrame {
    private JTextField nameField;
    private JTextField priceField;
    private JTextField quantityField;

    public AddProductFrame() {
        setTitle("Add Product");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        JLabel nameLabel = new JLabel("Nombre:");
        nameField = new JTextField();
        JLabel priceLabel = new JLabel("Precio:");
        priceField = new JTextField();
        JLabel quantityLabel = new JLabel("Cantidad:");
        quantityField = new JTextField();
        JButton saveButton = new JButton("Guardar");
        JButton salirButton = new JButton("Salir");
        

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(priceLabel);
        panel.add(priceField);
        panel.add(quantityLabel);
        panel.add(quantityField);
        panel.add(saveButton);
        panel.add(salirButton);

        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String priceStr = priceField.getText();
                String cantStr = quantityField.getText();

                boolean isValid = true;

                if (!name.matches("[a-zA-Z]+")) {
                    JOptionPane.showMessageDialog(null, "Nombre Invalido");
                    isValid = false;
                }

                if (!priceStr.matches("\\d+(\\.\\d+)?")) {
                    JOptionPane.showMessageDialog(null, "Precio invalido");
                    isValid = false;
                }

                if (!cantStr.matches("\\d+")) {
                    JOptionPane.showMessageDialog(null, "Cantidad invalida");
                    isValid = false;
                }

                if (isValid) {
                    double price = Double.parseDouble(priceStr);
                    int quantity = Integer.parseInt(cantStr);
                    
                    
                }
            }
        });
        salirButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panel.setVisible(false);
            }
        });
        add(panel);
        setVisible(true);
    }
}
