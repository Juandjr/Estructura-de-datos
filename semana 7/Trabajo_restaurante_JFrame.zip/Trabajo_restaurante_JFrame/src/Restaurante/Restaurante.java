package Restaurante;
//importamos las librerias que se van a utilizar para la elaboracion del programa
import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;
//clase Restaurante donde este realiza la funcion de agregar los pedidos a la cocina y la preparacion y la entrega de este
public class Restaurante {
    //creamos la pila y la cola que se va a utilizar en la clase
    Stack<String> pedidosPend = new Stack<String>();
    Queue<String> pedidosPrep = new LinkedList<String>();
    //constructor de la clase restaurante 
    Restaurante(){
        Stack<String> pedidosPend = new Stack<String>();
        Queue<String> pedidosPrep = new LinkedList<String>();
    }
    //metodo para agregar un pedido a la cocina
    public void agregarPedido(String newPedido){
        pedidosPend.add(newPedido);
        System.out.println("Pedido Agregado correctamente");
    }
    //metodo para preparar el pedido a la cocina
    public void prepararPedido(){
        pedidosPrep.add(pedidosPend.pop());
        System.out.println("Se esta preparando el pedido");
    }
    //metodo para entregar el pedido al cliente
    public void entregarPedido(){
        System.out.println("Se entrego el pedido correctamente");
        System.out.println(pedidosPrep.poll());
    }
}
