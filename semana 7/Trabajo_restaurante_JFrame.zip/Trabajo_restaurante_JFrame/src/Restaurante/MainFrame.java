package Restaurante;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainFrame extends JFrame {
    public MainFrame() {
        Pedido ped;
        Restaurante res = new Restaurante();
        Boton3 boton3 = new Boton3();
        Boton4 boton4 = new Boton4();
        Boton5 boton5 = new Boton5();
        Boton6 boton6 = new Boton6();
        AddProductFrame añaprodu = new AddProductFrame();
        setTitle("Restaurant Management");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        JPanel panel1 = new JPanel();
        panel1.setSize(200, 200);
        JPanel panel2 = new JPanel();
        panel2.setSize(200, 200);
        panel.setLayout(new GridLayout(3, 3));

        JButton button1 = new JButton("Añadir producto");
        JButton button2 = new JButton("Añadir Orden");
        JButton button3 = new JButton("Preparar Orden");
        JButton button4 = new JButton("Entregar Orden");
        JButton button5 = new JButton("Platos en la cocina");
        JButton button6 = new JButton("Platos en el comedor");
        JButton button7 = new JButton("Cerrar");

        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                añaprodu.setVisible(true);
            }
        });

        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add order functionality
            }
        });
        
        button3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add order functionality
                boton3.setVisible(true);
                res.prepararPedido();
            }
        });
        
        button4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add order functionality
                boton4.setVisible(true);
                    FileWriter fileWriter;
                try {
                    fileWriter = new FileWriter("datosRest.txt");
                    fileWriter.write(res.pedidosPrep.peek());
                    fileWriter.close();
                } catch (IOException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
                res.entregarPedido();
                
            }
        });
        
        button5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add order functionality
                boton5.setVisible(true);
            }
        });
        
        button6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add order functionality
                boton6.setVisible(true);
            }
        });

        // Add action listeners for button3 to button6

        button7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(button4);
        panel.add(button5);
        panel.add(button6);
        panel.add(button7);

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}                


