package Supermercado;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opc;
		Scanner scan = new Scanner(System.in);
		//llamamos a la clase Cajas
		Cajas caja = new Cajas();
		//llamamos a la clase productos
		Productos produ = new Productos();
		//Menu de opciones que aparece en pantalla al iniciar el programa
		System.out.println("===Menu de opciones===");
		System.out.println("1. Adicionar nuevo cliente a la cola de una caja.");
		System.out.println("2. Atender cliente en una caja.");
		System.out.println("3. Visualizar estado de una cola específica o de todas.");
		System.out.println("4. Adicionar nuevo producto al supermercado");
		System.out.println("5. Visualizar stock de un producto específico o de todos.");
		System.out.println("6. Mostrar menú nuevamente.");
		System.out.println("0.Salir");
		opc = scan.nextInt();
		while(opc!=0) {
			switch(opc) {
			        //caso 1 donde se añade un cliente a la cola de la caja
			        case 1:
			        	caja.nuevoCliente();
					break;
					//case 2 donde se atiende el cliente
					case 2:
						caja.nuevoClienteAtendido();
					break;
					//caso 3 donde logra visualizar las lista de los clientes
					case 3:
						caja.estadoDeCola();
					break;
					//caso 4 donde se añade un nuevo producto al supermercado
					case 4:
						produ.ingresarProducto();
					break;
					//caso 5 donde se mira el stock de uno o varios articulos
					case 5:
					    produ.mostrarProductos();
					break;
					//caso 6 donde se muestra el menu de productos
					case 6:
						produ.Menu();
					break;
					default:
						//aqui es donde se muestra un mensaje en caso de no elejir una opcion valida
						System.out.println("Opcion no valida");
					break;	
			}
			//aqui se vuelve a mostrar el menu de opciones en cuando se acabe de realizar una funcion
			System.out.println("===Menu de opciones===");
			System.out.println("1. Adicionar nuevo cliente a la cola de una caja.");
			System.out.println("2. Atender cliente en una caja.");
			System.out.println("3. Visualizar estado de una cola específica o de todas.");
			System.out.println("4. Adicionar nuevo producto al supermercado");
			System.out.println("5. Visualizar stock de un producto específico o de todos.");
			System.out.println("6. Mostrar menú nuevamente.");
			System.out.println("0.Salir");
			opc = scan.nextInt();
		}
		//mensaje que sale al pulsar 5 (opcion para salir) 
		System.out.println("Gracias por ingresar");
}
}
