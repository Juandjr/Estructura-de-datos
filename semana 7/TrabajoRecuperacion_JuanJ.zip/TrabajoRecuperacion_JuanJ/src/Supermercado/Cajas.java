package Supermercado;
import java.util.Scanner;
public class Cajas {
	//declaracion de las variables de la clase Cajas
	Scanner scan = new Scanner(System.in);
	int tamanio = 1;
	String nuevoCliente;
	//llamado a la clase Clientes
	Clientes cliente = new Clientes();
	//creacion del array dinamico
	int[] Cajas = new int[tamanio];
	//metodo para añadir un nuevo cliente a la cola
	public void nuevoCliente() {
		System.out.println("Ingrese el numero del cliente: ");
		nuevoCliente = scan.next();
		cliente.Cliente.offer(nuevoCliente);
		System.out.println("Cliente agregado exitosamente");
	}
	//metodo para añadir el nuevo cliente que estara en la cima de la cola
	public void nuevoClienteAtendido() {
		if(cliente.Cliente.size()!=0) {
		cliente.Cliente.poll();
		System.out.println("El cliente a sido atendido correctamente");
		}else {
			System.out.println("La cola esta vacia");
		}
	}
	//metodo para mostrar el estado de la cola
	public void estadoDeCola() {
		if(cliente.Cliente.size()!=0) {
		System.out.println("El Sujeto que esta en la primero en la cola es: "+cliente.Cliente.peek());
		System.out.println("El tamaño de la cola es de: "+cliente.Cliente.size());
		}else {
			System.out.println("La cola esta vacia");
		}
	}
}
