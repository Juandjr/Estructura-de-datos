package Supermercado;
import java.util.LinkedList;
import java.util.Queue;

public class Clientes {
	//creacion de la cola de clientes
		Queue<String> Cliente = new LinkedList<String>();
}
