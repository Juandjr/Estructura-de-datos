package Supermercado;
import java.util.Stack;
import java.util.Scanner;
public class Productos {
	//declaracion de las variables de productos
	String nombreProdu;
	int cantProdu;
	int opc;
	Scanner scan = new Scanner(System.in);
	//declaracion de la pila productors en java
	Stack<String> producto = new Stack<String>();
	Stack<Integer> stockProdu = new Stack<Integer>();
	//metodo para agregar un producto al stock del supermercado
	public void ingresarProducto() {
		System.out.println("Ingrese el nombre del nuevo producto: ");
		nombreProdu = scan.next();
		producto.add(nombreProdu);
		System.out.println("Ingrese la cantidad que hay en stock del producto: ");
		cantProdu = scan.nextInt();
		stockProdu.add(cantProdu);
		System.out.println("El producto a sido agregado correctamente");
	}
	//metodo para mostrar un o los productos que hay en stock
	public void mostrarProductos() {
		System.out.println("1. Un producto en especifico");
		System.out.println("2. todos los productos");
		System.out.println("3. Salir");
		opc = scan.nextInt();
		while (opc!=3) {
			switch(opc) {
			//opcion 1 que muestra 1 solo producto especificado por el usuario
			case 1:
				if(producto.size()!=0) {
					System.out.print("Producto: "+producto.peek()+" ");
					System.out.print("Cantidad: "+stockProdu.peek()+" ");
					System.out.println(" ");
				}else {
					System.out.println("No hay productos en el stock");
				}
				break;
				//opcion2 que muestra todos los productos
			case 2:
				if(producto.size()!=0) {
					while(!producto.isEmpty()) {
						System.out.print("Producto: "+producto.pop()+" ");
						System.out.print("Cantidad: "+stockProdu.pop()+" ");
					    System.out.println("");
					}
				}else {
					System.out.println("No hay productos en el stock");
				}
				break;
				//opcion que sale cuando no se selecciona ninguno de los casos especificados
		    default:
		    	System.out.println("Opcion no valida");
				break;
			}
			System.out.println("1. Un producto en especifico");
			System.out.println("2. todos los productos");
			System.out.println("3. Salir");
			opc = scan.nextInt();
		}
	}
	
	//metodo para mostrar el menu de los productos que hay actualmente en stock
	public void Menu() {
		if(producto.size()!=0) {
			while(!producto.isEmpty()) {
				System.out.print("Producto: "+producto.pop()+" ");
			    System.out.println("");
			}
		}else {
			System.out.println("No hay productos en el stock");
		}
	}
	
}
