package lab2;
import java.util.Queue;
import java.util.Stack;
import java.util.LinkedList;

public class Restaurante {
	//creacion de la lista pedidosPendientes y la cola pedidosPreparados
	Stack<Pedido> pedidosPendientes = new Stack<>();
    Queue<Pedido> pedidosPreparados = new LinkedList<>();
    
    //metodo agregarPedido que como dice su nombre agrega el pedido a la lista
    public void agregarPedido(Pedido pedido) {
        pedidosPendientes.push(pedido);
    }
    
    //metodo prepararPedidoActual donde el valor que esta en pedidosPendientes se guarda en un pedido y lo elimina de la lista pedidoPendientes
    //y se añade a la cola pedidosPreparados el pedido que se elimino de pedidosPendientes
    public void prepararPedidoActual() {
        Pedido pedido = pedidosPendientes.pop();
        pedidosPreparados.add(pedido);
    }
    
    //Metodo que borra de la cola el primer pedidoPreparado
    public void entregarPedidoPreparado() {
        pedidosPreparados.poll();
    }
    
    //metodo que muestra los pedidos 
    public void mostrarPedidos() {
		for(int i=0;i<pedidosPreparados.size();i++)
			pedidosPreparados.poll();
}
}
