package lab2;
import java.util.LinkedList;
import java.util.Queue;
public class Pedido {
	//atributos de la clase pedido
	int numeroPedido;
    String nombreCliente;
    Queue<Producto> productos = new LinkedList<>();
    //constructor de la clase pedidos donde se inicializa los valores de numeroPedido y nombreCliente
    public Pedido(int numeroPedido, String nombreCliente) {
        this.numeroPedido = numeroPedido;
        this.nombreCliente = nombreCliente;
    }
    
    //Metodo que sirve para agregar los productos
    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }
    
    
}
