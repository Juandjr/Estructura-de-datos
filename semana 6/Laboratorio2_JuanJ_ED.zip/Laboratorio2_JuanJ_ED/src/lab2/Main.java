package lab2;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Restaurante restaurante = new Restaurante();
		plato plato = new plato();
		String a;
		double b;
		int opc,c;
		Scanner scan = new Scanner(System.in);
		//Menu de opciones que aparece en pantalla al iniciar el programa
		System.out.println("===Menu de opciones===");
		System.out.println("1. Agregar Pedido a la Cocina");
		System.out.println("2. Servir Pedido en el Comedor");
		System.out.println("3. Mostrar Pedidos en el Comedor");
		System.out.println("4. Eliminar Pedido de la Cocina");
		System.out.println("5.Salir");
		opc = scan.nextInt();
		while(opc!=5) {
			switch(opc) {
			//caso 1 donde se agrega el pedido a la cocina
			        case 1:
			        	System.out.println("Ingrese los datos del que pidio el producto");
			        	System.out.println("Numero del pedido: ");
			        	c = scan.nextInt();
			        	System.out.println("Ingrese  el nombre del cliente: ");
			        	a = scan.next();
			        	Pedido pedido = new Pedido(c, a);
			        	System.out.println("Ingrese los datos del producto");
			        	System.out.println("Ingrese el platillo: ");
			        	a = scan.next();
			        	System.out.println("Ingrese el valor del platillo: ");
			        	b = scan.nextDouble();
			        	System.out.println("Ingrese la cantidad que desea del platillo: ");
			        	c = scan.nextInt();
			        	pedido.agregarProducto(new Producto(a, b, c));
			        	restaurante.agregarPedido(pedido);
					break;
					//case 2 donde se enrega el plato al comedor 
					case 2:
						restaurante.entregarPedidoPreparado();
						restaurante.prepararPedidoActual();
						System.out.println("Se entregaron los productos exitosamente");
					break;
					//caso 3 donde se muestra la lista de los pedidos
					case 3:
						System.out.println("Esta es la lista de los Pedidos: ");
						restaurante.mostrarPedidos();
					break;
					case 4:
						//caso donde se elimina un pedido especifico de los pedidos
						plato.eliminarPedidoCocina();
						System.out.println("Se elimino el pedido correctamente");
					break;
					default:
						//aqui es donde se muestra un mensaje en caso de no elejir una opcion valida
						System.out.println("Opcion no valida");
					break;	
			}
			//aqui se vuelve a mostrar el menu de opciones en cuando se acabe de realizar una funcion
			System.out.println("===Menu de opciones===");
			System.out.println("1. Agregar Pedido a la Cocina");
			System.out.println("2. Servir Pedido en el Comedor");
			System.out.println("3. Mostrar Pedidos en el Comedor");
			System.out.println("4. Eliminar Pedido de la Cocina");
			System.out.println("5.Salir");
			opc = scan.nextInt();
		}
		//mensaje que sale al pulsar 5 (opcion para salir) 
		System.out.println("Gracias por ingresar");
}
}

