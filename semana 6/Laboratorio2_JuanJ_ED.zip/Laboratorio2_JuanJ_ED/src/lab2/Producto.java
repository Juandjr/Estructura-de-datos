package lab2;
import java.util.Queue;
public class Producto {
	//atributos de la clase producto
	String nombre;
    double precio;
    int cantidad;
    //Constructor que inicializa los valores de nombre, precio, cantidad
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
}
