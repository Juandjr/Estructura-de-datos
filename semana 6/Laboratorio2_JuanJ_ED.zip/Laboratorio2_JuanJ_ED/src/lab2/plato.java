package lab2;

public class plato {
	//se declaran los atributos de la clase plato
	String nombre;
	String tipo;
	double precio;
	Pedido pedido= new Pedido(0,null);
	
	//metodo que elimina un pedido de la cocina
	public void eliminarPedidoCocina() {
		pedido.productos.poll();
	}
	
	//metodo que muestra los platos que ya se estan hechos 
	public void mostrarPlatos() {
		while(!(pedido.productos.peek()==null)) {
			pedido.productos.poll();
		}
	}
}
