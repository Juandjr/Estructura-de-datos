package practica6;
import java.util.Stack;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Pilas {
	int tamaño;//tamaño de la pila
	Scanner scan = new Scanner(System.in);
	String A,B,C,D,E,F,pe;
	Stack <String> titulo = new Stack<String>();
	Stack <String> autor = new Stack<String>();
	Stack <Integer> año = new Stack<Integer>();
	List<String>BolsaTitulo = new ArrayList<>();
	List<String>BolsaAutor = new ArrayList<>();
	List<String>BolsaAño = new ArrayList<>();

		
	public void mostrarRega() {
	    if (año == null) {
	        System.out.println("La pila está vacía.");
	        return;
	    }
	    Stack<Integer> current = año;
	    while (año != null) {
	        if (current.lastElement() < 2020) {
	            BolsaTitulo.add(titulo.toString());
	            BolsaAutor.add(autor.toString());
	            BolsaAño.add(año.toString());
	        }
	        current = current.pop();
	    }
	    if (BolsaTitulo.size() == 0) {
	        System.out.println("No se encontraron libros menores a 2020.");
	        return;
	    }
	    for (int i = 0; i < BolsaTitulo.size(); i++) {
	        System.out.println("Título: " + BolsaTitulo.get(i));
	        System.out.println("Autor: " + BolsaAutor.get(i));
	        System.out.println("Año: " + BolsaAño.get(i));
	    }
	}
	
	public void mostrarLibrosSobrantes() {
		
		
	}
	
	public void modificarPila() {
		System.out.println("Ingrese el dato que desea reemplazar: ");
		System.out.println("Titulo: ");
		A = scan.next();
		System.out.println("Autor: ");
		B = scan.next();
		System.out.println("Año de edicion: ");
		C = scan.next();
		System.out.println("Ingrese el nuevo dato");
		System.out.println("Nuevo Titulo: ");
		D = scan.next();
		System.out.println("Nuevo autor: ");
		E = scan.next();
		System.out.println("Nuevo año de edicion: ");
		F = scan.next();
		
	}
	
	
	
	
}
