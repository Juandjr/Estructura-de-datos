package practica6;
import java.util.Scanner;
public class GenerarPila {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pilas miPila = new Pilas();//Crear una instancia de la pila
		//Operaciones basicas de la pila
		Scanner scan = new Scanner(System.in);
		int opc,cant,dato;
		String A,B,C;
		System.out.println("===Menu de Opciones===");
		System.out.println("1.Ingresar Libros");
		System.out.println("2.Regalar libros menor 2020");
		System.out.println("3.Ordenar Alfabeticamente");
		System.out.println("4.Modificar informacion de un libro");
		System.out.println("5.Contar libros en la bolsa de regalos");
		System.out.println("6. Buscar libros por rango de años");
		System.out.println("7.Salir");
		opc = scan.nextInt();
		while(opc !=7) {
			switch(opc) {
			case 1:
				System.out.println("Ingresa la cantidad de libros que desees ingresar");
				cant = scan.nextInt();
				for (int i=0;i<cant;i++) {
					System.out.println("Ingrese el Titulo del libro N° "+(i+1)+" :");
					A = scan.next();
					miPila.titulo.add(A);
					System.out.println("Ingrese el Autor del libro N° "+(i+1)+" :");
					A = scan.next();
					miPila.autor.add(A);
					System.out.println("Ingrese el Año de edicion del libro N° "+(i+1)+" :");
					dato = scan.nextInt();
					miPila.año.add(dato);
				}
				System.out.println("Los datos han sido ingresados correctamente");
				break;
			case 2:
				miPila.mostrarRega();
				break;
			case 3:
				miPila.mostrarLibrosSobrantes();
				break;
			case 4:
				System.out.println("El tamaño de la pila es de: "+miPila.tamaño);
				break;
			case 5:
				System.out.println("El numero de datos los libros regalados es: "+ miPila.BolsaTitulo.size());
				break;
			case 6:
				
				break;
			default:
				System.out.println("Opcion no valida");
				break;
			}
			System.out.println("===Menu de Opciones===");
			System.out.println("1.Ingresar Libros");
			System.out.println("2.Regalar libros menor 2020");
			System.out.println("3.Ordenar Alfabeticamente");
			System.out.println("4.Modificar informacion de un libro");
			System.out.println("5.Contar libros en la bolsa de regalos");
			System.out.println("6. Buscar libros por rango de años");
			System.out.println("7.Salir");
			opc = scan.nextInt();
		}
		System.out.println("Gracias por ingresar");
	}
}
