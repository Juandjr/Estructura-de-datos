
package arbolgenealogico_lab1_u2_juanj;

public class Node {//declaracion de la clase Node
    //declaracion de las variables
    public String value;
    public Node left;
    public Node right;
    //constructor de la clase Node
    public Node (String value, String nombre, String fechaNacimiento, String genero, String estado){//formato del contructor
        this.value = (value = String.format("""
                    Nombre:  %s
                     Fecha de nacimiento: %s
                     Genero:  %s
                     Estado: %s
                     -----------------------------------
                     """, nombre, fechaNacimiento,genero,estado));//se le crea un diseño al String value para mostrar los datos de una forma deseada
    }
}
