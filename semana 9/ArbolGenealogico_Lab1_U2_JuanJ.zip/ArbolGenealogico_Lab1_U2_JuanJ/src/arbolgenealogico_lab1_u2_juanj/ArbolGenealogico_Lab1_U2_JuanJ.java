
package arbolgenealogico_lab1_u2_juanj;

public class ArbolGenealogico_Lab1_U2_JuanJ {
    
    public static void main(String[] args) {
        //se ingresaban los datos al nodo principal
        Node root = new Node("a","Alfonso Romero","16/08/1947","Masculino","Vivo");
        //se agregan las ramas
        root.left = new Node("b","Flor Romero","02/05/1967","Femenino","Vivo");
        root.right = new Node("c","Paty Romero","20/02/1968","Femenino","Vivo");
        root.left = new Node("d","Flor Romero","02/05/1967","Femenino","Vivo");
        root.left = new Node("e","Diana Romero","13/07/1967","Femenino","Vivo");
        root.left.left = new Node("d","d","","","");
        root.left.right = new Node("e","e","","","");

        root.right.right = new Node("f","f","","","");

        root.left.left.left = new Node("g","g","","","");

        root.left.right.left = new Node("h","h","","","");
        //llamada a las los metodos para el recorrido del arbol binario in Orden
        System.out.println("IN-ORDER TRAVERSAL: ");
        BinaryTreeTraversals.inOrdenTraversal(root);
        System.out.println();
        //llamada al metodo para el reccorido del arbol binario pre Orden
        System.out.println("PRE-ORDER TRAVERSAL: ");
        BinaryTreeTraversals.preOrdenTraversal(root);
        System.out.println();
        //llamada al metodo para el recorrido del arbol binario post orden
        System.out.println("POST-ORDER TRAVERSAL: ");
        BinaryTreeTraversals.postOrdenTraversal(root);
        System.out.println();
    }
}
