
package arbolgenealogico_lab1_u2_juanj;
//clase Binary Tree Traversals donde estan los metodos para el recorrido del arbol binario
public class BinaryTreeTraversals {
    //metodo para realizar el recorrido inOrden del arbol donde se pide un nodo para recorrerlo
    public static void inOrdenTraversal(Node node){
        if(node !=null){//validacion del metodo para no realizarlo en caso de estar vacio
            inOrdenTraversal(node.left);//la forma de recorrido dice que empieza desde la izquierda
            System.out.print(node.value+" ");//imprime el valor da value y le da un espaciado
            inOrdenTraversal(node.right);//toma el valor de la derecha
    }}
    //metodo para realizar el recorrido preOrden del arbol 
    public static void preOrdenTraversal(Node node){
        if(node !=null){//validacion del metodo para no realizarlo en caso de estar vacio
           System.out.print(node.value+" ");//imprime el valor da value y le da un espaciado
           preOrdenTraversal(node.left);//toma el valor de la izquierda
           preOrdenTraversal(node.right);//toma el valor de la derecha
    }}
    //metodo para realizar el recorrido postOrden del arbol
    public static void postOrdenTraversal (Node node){
        if(node !=null){//validacion del metodo para no realizarlo en caso de estar vacio
            postOrdenTraversal(node.left);//la forma de recorrido dice que empieza desde la izquierda
            postOrdenTraversal(node.right);//toma el valor de la derecha
            System.out.print(node.value+" ");//imprime el valor da value y le da un espaciado
    }}
}
