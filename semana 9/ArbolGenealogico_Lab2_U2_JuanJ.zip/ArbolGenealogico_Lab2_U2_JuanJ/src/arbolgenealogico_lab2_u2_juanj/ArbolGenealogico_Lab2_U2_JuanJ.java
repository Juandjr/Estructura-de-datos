
package arbolgenealogico_lab2_u2_juanj;

import java.util.Scanner;

public class ArbolGenealogico_Lab2_U2_JuanJ {
private NodoArbol arbol1 = null;
CraerArbolGenealogico arbol = new CraerArbolGenealogico();
    public static void main(String[] args) {
        
        ArbolGenealogico_Lab2_U2_JuanJ xd = new ArbolGenealogico_Lab2_U2_JuanJ ();
        xd.Ejecutar();
            
    }
    
    public void Ejecutar(){
        
        Persona abuelo = new Persona("Abuelo", "01/01/1950", "Masculino");
        Persona abuela = new Persona("Abuela", "01/01/1952", "Femenino");
        Persona padre = new Persona("Padre", "01/01/1975", "Masculino");
        Persona madre = new Persona("Madre", "01/01/1980", "Femenino");
        Persona hijo = new Persona("Hijo", "01/01/2000", "Masculino");
        arbol.agregarPersona(abuelo);
        arbol.agregarPersona(abuela);
        arbol.agregarPersona(padre);
        arbol.agregarPersona(madre);
        arbol.agregarPersona(hijo);
        arbol.agregarPadres(padre, abuelo, abuela);
        arbol.agregarHijo(padre, madre, hijo);
        arbol.imprimirArbol();
        buscarNodo();
}
    
    
    
    private void buscarNodoArbol(String nombre, boolean eliminar) {
 int rondas = 0;
 NodoArbol buscando = arbol1;
 NodoArbol previo = null;
 while (buscando != null) {
 rondas++;
 if (nombre == buscando.nombre) break;
 else previo = buscando;
 if (nombre != buscando.nombre) buscando = buscando.izquierda;
 else buscando = buscando.derecha;
 }
 if (buscando == null) System.out.println("\nNodo " + nombre + " no encontrado");
 else {
 if (!eliminar) System.out.println("\nNodo " + nombre + " encontrado después de " +
rondas + " rondas");
 else eliminarNodoArbol(buscando, previo);
 }
 }
    private void buscarNodo() {
 Scanner scanner = new Scanner(System.in);
 System.out.print("¿Qué familiar desea buscar?: ");
 String nombre = scanner.next();
 buscarNodoArbol(nombre, false);
 }
    
 private void eliminarNodoArbol(NodoArbol aux, NodoArbol prev) {
 if (aux != null) {
 eliminarNodoArbol(aux.izquierda, aux);
 eliminarNodoArbol(aux.derecha, aux);
 System.out.println("\nNodo Eliminado: " + aux.nombre);
 if (prev != null) {
 if (aux.nombre != prev.nombre) prev.izquierda = null;
 else prev.derecha = null;
 }
 if (aux == arbol1) arbol1 = null;
 // Borrar nodo.
 aux = null;
 }
 }
}
