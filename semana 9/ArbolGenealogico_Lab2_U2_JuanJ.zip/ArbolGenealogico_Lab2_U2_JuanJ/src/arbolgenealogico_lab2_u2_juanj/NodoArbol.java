
package arbolgenealogico_lab2_u2_juanj;

public class NodoArbol {
    public String nombre;
 public NodoArbol izquierda;
 public NodoArbol derecha;
 public NodoArbol(String nombre) {
 this.nombre = nombre;
 izquierda = null;
 derecha = null;
 }
}

