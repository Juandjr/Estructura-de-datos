
package arbolbinario_juanj_2u;

public class ArbolBinario_JuanJ_2U {

    public static void main(String[] args) {
        // TODO code application logic here
        
      
       
    Node root = new Node(1);
    root.left = new Node(2);
    root.right = new Node(3);

    root.left.left = new Node(4);
    root.left.right = new Node(5);

    root.right.right = new Node(6);

    root.left.left.left = new Node(7);

    root.left.right.left = new Node(8);

    System.out.print("IN-ORDER TRAVERSAL: ");
    BinaryTreeTraversals.inOrdenTraversal(root);
    System.out.println();

    System.out.print("PRE-ORDER TRAVERSAL: ");
    BinaryTreeTraversals.preOrdenTraversal(root);
    System.out.println();

    System.out.print("POST-ORDER TRAVERSAL: ");
    BinaryTreeTraversals.postOrdenTraversal(root);
    System.out.println();
  }
    
}
