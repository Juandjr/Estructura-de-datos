
package arbolbinario_juanj_2u;

public class Node {
    public int value;
    public Node left;
    public Node right;
    
    public Node (int value){
        this.value = value;
    }
}
