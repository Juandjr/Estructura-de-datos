
package arbolbinario_juanj_2u;

public class BinaryTreeTraversals {
    public static void inOrdenTraversal(Node node){
        if(node !=null){
            inOrdenTraversal(node.left);
            System.out.print(node.value+" ");
            inOrdenTraversal(node.right);
    }}
    
    public static void preOrdenTraversal(Node node){
        if(node !=null){
           System.out.print(node.value+" ");
           preOrdenTraversal(node.left);
           preOrdenTraversal(node.right);
    }}
    
    public static void postOrdenTraversal (Node node){
        if(node !=null){
            postOrdenTraversal(node.left);
            postOrdenTraversal(node.right);
            System.out.print(node.value+" ");
    }}
}
