
package TestArbolBinario;
import arbolbinario_juanj_2u.Node;
import arbolbinario_juanj_2u.BinaryTreeTraversals;

public class testArbolBinario {
    
    public void test(){
        Node root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.right.right = new Node(6);
        root.left.left.left = new Node(7);
        root.left.right.left = new Node(8);
        System.out.println("IN-ORDEN TRAVERSAL: ");
        BinaryTreeTraversals.inOrdenTraversal(root);
        System.out.println();
        System.out.println("PRE-ORDEN TRAVERSAL: ");
        BinaryTreeTraversals.preOrdenTraversal(root);
        System.out.println();
        System.out.println("POST-ORDEN TRAVERSAL: ");
        BinaryTreeTraversals.postOrdenTraversal(root);
        System.out.println();
    }
}
